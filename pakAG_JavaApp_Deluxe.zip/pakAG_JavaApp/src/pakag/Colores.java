package pakag;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

/**
 * ESTILO ETA DISEINUA:
 * Colores klaseak aplikazioaren itxura bisual osoa zentralizatzen du.
 * Hemen definitzen dira erabiliko diren kolore-paleta, iturriak (fonts) 
 * eta botoi estilo estandarizatuak koherentzia mantentzeko.
 */
public class Colores {
    
    // --- KOLORE PALETA (Konstanteak) ---
    
    // Albo-barrako (Sidebar) koloreak
    public static final Color SIDEBAR_BG     = new Color(0x1a2e3b); // Urdin iluna (atzealdea)
    public static final Color SIDEBAR_ACTIVE = new Color(0x2a3f50); // Aukeratutako aukeraren kolorea
    
    // Kolore nagusiak
    public static final Color ACCENT         = new Color(0x4db8a4); // Berde esmeralda (ekintza nagusiak)
    public static final Color HEADER_BG      = new Color(0x1a3a4a); // Goiburukoen atzealdea
    public static final Color WHITE          = Color.WHITE;
    public static final Color BG             = new Color(0xf0f2f5); // Pantailaren atzealde argia
    
    // Testu eta ertzen koloreak
    public static final Color BORDER_COLOR   = new Color(0xe0e4e8); // Banatzaile eta markoetarako
    public static final Color TEXT_DARK      = new Color(0x1a2e3b); // Testu nagusia (irakurgarritasun altua)
    public static final Color TEXT_MUTED     = new Color(0x666666); // Testu sekundarioa edo laguntzailea
    public static final Color ICON_BG        = new Color(0xe8f7f3); // Ikonoen atzealdeko borobila
    
    // Egoera-txartelak (Badges) - Elementuen egoerak bereizteko
    public static final Color BADGE_RUTA     = new Color(0x22c55e); // Bidean
    public static final Color BADGE_ALMACEN  = new Color(0x3b82f6); // Biltegian
    public static final Color BADGE_ENTREGADO= new Color(0x9ca3af); // Entregatua
    public static final Color BADGE_AKTIBO   = new Color(0x22c55e); // Aktibo (Berdea)
    public static final Color BADGE_INAKTIBO = new Color(0xef4444); // Inaktibo (Gorria)

    /**
     * Atalen goiburuko estilotsua sortzen du.
     * @param text Goiburukoan agertuko den testua.
     * @return Diseinatutako JLabel objektua.
     */
    public static JLabel sectionHeader(String text) {
        JLabel h = new JLabel(text);
        h.setFont(new Font("Segoe UI", Font.BOLD, 12));
        h.setForeground(WHITE);
        h.setBackground(HEADER_BG);
        h.setOpaque(true); // Atzealdeko kolorea ikusteko beharrezkoa
        h.setBorder(new EmptyBorder(9, 14, 9, 14)); // Barneko tartea (Padding)
        return h;
    }

    /**
     * Ekintza nagusietarako botoia (Adibidez: Gorde, Gehitu).
     * @param text Botoiaren testua.
     * @return Botoi berde eta modernoa.
     */
    public static JButton accentButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setForeground(WHITE);
        btn.setBackground(ACCENT);
        btn.setBorderPainted(false); // Ertz estandarra kendu
        btn.setFocusPainted(false);  // Klik egitean marko itsusia kendu
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Eskua erakutsi gainetik pasatzean
        btn.setBorder(new EmptyBorder(7, 16, 7, 16));
        return btn;
    }

    /**
     * Arriskua adierazten duten ekintzetarako botoia (Adibidez: Ezabatu).
     * @param text Botoiaren testua.
     * @return Botoi gorri deigarria.
     */
    public static JButton dangerButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setForeground(WHITE);
        btn.setBackground(new Color(0xef4444)); // Gorria
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(new EmptyBorder(7, 16, 7, 16));
        return btn;
    }

    /**
     * Ekintza sekundarioetarako botoia (Adibidez: Utzi, Itxi).
     * @param text Botoiaren testua.
     * @return Botoi gris argi eta diskretua.
     */
    public static JButton neutralButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btn.setForeground(TEXT_DARK);
        btn.setBackground(new Color(0xe8edf2)); // Gris-urdinxka argia
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(new EmptyBorder(7, 16, 7, 16));
        return btn;
    }
}