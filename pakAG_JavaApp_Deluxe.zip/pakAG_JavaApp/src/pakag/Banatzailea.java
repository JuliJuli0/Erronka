package pakag;

/**
 * Banatzailea klasea: Banatzaile baten informazioa kudeatzeko erabilia.
 * Erabiltzailearen datu pertsonalak eta sistemako sarbide datuak gordetzen ditu.
 */
public class Banatzailea {
    
    // --- ATRIBUTUAK ---
    private String id;            // Banatzailearen NAN zenbakia (identifikatzaile bakarra)
    private String izena;         // Banatzailearen izena
    private String abizena;       // Banatzailearen abizena
    private String erabiltzailea; // Sisteman sartzeko erabiltzaile izena
    private String pasahitza;     // Sisteman sartzeko pasahitza
    private String rola;          // Erabiltzailearen rola (adibidez: "Banatzailea")
    private String helbidea;      // Banatzailearen egoitza edo helbidea
    private String telefonoa;     // Kontakturako telefono zenbakia

    /**
     * Banatzailea klasearen eraikitzailea.
     * * @param id            NAN zenbakia.
     * @param izena         Pertsonaren izena.
     * @param abizena       Pertsonaren abizena.
     * @param erabiltzailea Saioa hasteko izena.
     * @param pasahitza     Sarbide gakoa.
     * @param rola          Sisteman duen baimen maila.
     * @param helbidea      Bizileku edo lan helbidea.
     */
    public Banatzailea(String id, String izena, String abizena, String erabiltzailea, String pasahitza, String rola, String helbidea) {
        this.id = id;
        this.izena = izena;
        this.abizena = abizena;
        this.erabiltzailea = erabiltzailea;
        this.pasahitza = pasahitza;
        this.rola = rola;
        this.helbidea = helbidea;
    }

    // --- GETTERS (Balioak lortzeko) ---

    /** @return Id-a (NAN) bueltatzen du. */
    public String getId() { return id; }

    /** @return Izena bueltatzen du. */
    public String getIzena() { return izena; }

    /** @return Abizena bueltatzen du. */
    public String getAbizena() { return abizena; }

    /** @return Erabiltzaile izena bueltatzen du. */
    public String getErabiltzailea() { return erabiltzailea; }

    /** @return Pasahitza bueltatzen du. */
    public String getPasahitza() { return pasahitza; }

    /** @return Rola bueltatzen du. */
    public String getRola() { return rola; }

    /** @return Helbidea bueltatzen du. */
    public String getHelbidea() { return helbidea; }

    /** @return Telefonoa bueltatzen du. */
    public String getTelefonoa() { return telefonoa; }

    // --- SETTERS (Balioak aldatzeko) ---

    /** @param id NAN berria ezartzeko. */
    public void setId(String id) { this.id = id; }

    /** @param izena Izen berria ezartzeko. */
    public void setIzena(String izena) { this.izena = izena; }

    /** @param abizena Abizen berria ezartzeko. */
    public void setAbizena(String abizena) { this.abizena = abizena; }

    /** @param erabiltzailea Erabiltzaile berria ezartzeko. */
    public void setErabiltzailea(String erabiltzailea) { this.erabiltzailea = erabiltzailea; }

    /** @param pasahitza Pasahitza berria ezartzeko. */
    public void setPasahitza(String pasahitza) { this.pasahitza = pasahitza; }

    /** @param rola Rol berria ezartzeko. */
    public void setRola(String rola) { this.rola = rola; }

    /** @param helbidea Helbide berria ezartzeko. */
    public void setHelbidea(String helbidea) { this.helbidea = helbidea; }

    /** @param telefonoa Telefono berria ezartzeko. */
    public void setTelefonoa(String telefonoa) { this.telefonoa = telefonoa; }
}