package pakag;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import javax.imageio.ImageIO;

/**
 * MAPA INTERAKTIBOA (Map Component):
 * Kanpoko zerbitzarietatik (OpenStreetMap) maparen irudiak deskargatzen ditu.
 * Paketeak helbidearen arabera geokodifikatzen ditu eta mapan markatzaileak jartzen ditu.
 */
public class MapCanvas extends JPanel {

    // --- KAXEAK ETA HILUAK (Performance) ---
    // Helbideak koordenatu bihurtuta gordetzen ditu behin bakarrik kalkulatzeko
    private static final Map<String, double[]> geoCache = new ConcurrentHashMap<>();
    // Maparen irudiak (tiles) deskargatzeko hiru-igerilekua (6 hari)
    private final ExecutorService tileLoader = Executors.newFixedThreadPool(6);
    // Irudiak memorian gordetzeko kaxea
    private final Map<String, BufferedImage> tileCache = new ConcurrentHashMap<>();
    
    // --- MAPAREN EGOERA ---
    private int zoom = 6;               // Hasierako zoom maila (Espainia ikusteko)
    private double centerLat = 40.416;  // Madrilen latitudea
    private double centerLon = -3.703;  // Madrilen longitudea
    private Point lastDrag;             // Arrastatze mugimendua kalkulatzeko
    
    // Paketeen zerrenda segurua (hari anitzeko ingurunerako)
    private List<Pakete> paquetes = new CopyOnWriteArrayList<>();
    private Pakete hoveredPaq = null;   // Saguaren azpian dagoen paketea
    private Point tooltipPt = null;     // Informazio-koadroaren posizioa

    /**
     * Eraikitzailea: Maparen atzealdea eta interakzioak prestatu.
     */
    public MapCanvas() {
        setBackground(new Color(0xd4e8f0)); // Itsasoaren kolorea
        setupInteraction();
    }

    /**
     * getCoords(): Helbide testu bat hartu eta koordenatu bihurtzen du (API bidez).
     * @param dest Helbidea (adib. "Bilbo, Abando")
     * @return [lat, lon] bikotea
     */
    private double[] getCoords(String dest) {
        if (dest == null || dest.isEmpty()) return new double[]{40.416, -3.703};
        if (geoCache.containsKey(dest)) return geoCache.get(dest);

        try {
            // OSM Nominatim API-ra deia
            String query = dest.toLowerCase().contains("españa") ? dest : dest + ", España";
            String urlStr = "https://nominatim.openstreetmap.org/search?format=json&q=" 
                            + URLEncoder.encode(query, "UTF-8") + "&limit=1";
            
            URL url = new URL(urlStr);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestProperty("User-Agent", "Mozilla/5.0 PakAG_Project_v2");
            con.setConnectTimeout(3000);

            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                StringBuilder res = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) res.append(line);
                
                String json = res.toString();
                // JSON-tik latitudea eta longitudea erauzi (regex gabe sinpletzeko)
                if (json.contains("\"lat\":\"")) {
                    double lat = Double.parseDouble(json.split("\"lat\":\"")[1].split("\"")[0]);
                    double lon = Double.parseDouble(json.split("\"lon\":\"")[1].split("\"")[0]);
                    double[] coords = {lat, lon};
                    geoCache.put(dest, coords); // Emaitza kaxean gorde
                    return coords;
                }
            }
        } catch (Exception e) {
            System.err.println("Errorea geokodifikazioan: " + e.getMessage());
        }
        return null; // Ezin bada aurkitu
    }

    
    /**
     * Kanpotik deitzeko metodoa, pakete bat mapan lokalizatzeko.
     * @param p Hautatutako paketea
     */
    public void aukeratuPakete(Pakete p) {
        if (p != null) {
            navegarA(p);
        }
    }
    
    /**
     * navegarA(): Mapa pakete zehatz baten kokapenera mugitzen du.
     */
    public void navegarA(Pakete p) {
        new Thread(() -> {
            double[] ll = getCoords(p.getDestino());
            if (ll != null) {
                centerLat = ll[0];
                centerLon = ll[1];
                zoom = 14; // Zoom hurbila ikusteko
                SwingUtilities.invokeLater(() -> {
                    tileCache.clear(); // Irudi berriak kargatzeko kaxea garbitu
                    repaint();
                });
            }
        }).start();
    }

    /**
     * cargarPuntosDesdeLista(): Panel nagusitik deitzen da pakete guztiak mapan marrazteko.
     */
    public void cargarPuntosDesdeLista(List<Pakete> nuevaLista) {
        if (nuevaLista == null) return;
        this.paquetes.clear();
        this.paquetes.addAll(nuevaLista);
        this.hoveredPaq = null;
        
        // Pakete bakoitzeko hari bat sortu (async) koordenatuak lortzeko
        for (Pakete p : this.paquetes) {
            if (p.getEstado().equalsIgnoreCase("Entregatuta")) continue;
            new Thread(() -> {
                if (getCoords(p.getDestino()) != null) {
                    SwingUtilities.invokeLater(this::repaint);
                }
            }).start();
        }
        repaint();
    }

    /**
     * setupInteraction(): Saguaren gurpilaren zoom-a eta arrastatze logikoa.
     */
    private void setupInteraction() {
        // Zoom maila aldatu saguaren gurpilarekin
        addMouseWheelListener(e -> {
            int delta = e.getWheelRotation() < 0 ? 1 : -1;
            zoom = Math.max(4, Math.min(18, zoom + delta));
            tileCache.clear();
            repaint();
        });

        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) { lastDrag = e.getPoint(); }
            public void mouseClicked(MouseEvent e) {
                if (hoveredPaq != null) navegarA(hoveredPaq);
            }
        });

        addMouseMotionListener(new MouseAdapter() {
            // Mapa mugitu saguarekin klik eginda daukagula
            public void mouseDragged(MouseEvent e) {
                if (lastDrag != null) {
                    double scale = 256.0 * (1 << zoom);
                    centerLon -= (e.getX() - lastDrag.x) / scale * 360.0;
                    centerLat += (e.getY() - lastDrag.y) / scale * 360.0 * Math.cos(Math.toRadians(centerLat));
                    lastDrag = e.getPoint();
                    repaint();
                }
            }
            // "Hover" efektua markatzaileen gainetik pasatzean
            public void mouseMoved(MouseEvent e) {
                Pakete found = null;
                Point fp = null;
                for (Pakete p : paquetes) {
                    if (p.getEstado().equalsIgnoreCase("Entregatuta")) continue;
                    double[] ll = geoCache.get(p.getDestino());
                    if (ll != null) {
                        Point pt = latLonToScreen(ll[0], ll[1]);
                        if (pt.distance(e.getPoint()) < 15) { // 15 pixeleko distantziara badago
                            found = p;
                            fp = pt;
                        }
                    }
                }
                hoveredPaq = found;
                tooltipPt = fp;
                setCursor(found != null ? Cursor.getPredefinedCursor(Cursor.HAND_CURSOR) : Cursor.getDefaultCursor());
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        drawTiles(g2);   // 1. Maparen irudiak marraztu
        drawMarkers(g2); // 2. Paketeen puntuak jarri
        drawLegend(g2);  // 3. Legenda (koloreak)
        if (hoveredPaq != null && tooltipPt != null) drawTooltip(g2); // 4. Info-koadroa
    }

    /**
     * drawTiles(): Pantailan ikusten den eremuko irudi koadroak (tiles) marraztu.
     */
    private void drawTiles(Graphics2D g2) {
        int w = getWidth(), h = getHeight(), ts = 256;
        if (w <= 0 || h <= 0) return;

        double ctx = lonToTileX(centerLon), cty = latToTileY(centerLat);
        int sx = (int) Math.floor(ctx - (double) w / (2 * ts));
        int sy = (int) Math.floor(cty - (double) h / (2 * ts));
        int ex = (int) Math.ceil(ctx + (double) w / (2 * ts));
        int ey = (int) Math.ceil(cty + (double) h / (2 * ts));
        int maxTile = 1 << zoom;

        for (int tx = sx; tx <= ex; tx++) {
            for (int ty = sy; ty <= ey; ty++) {
                int xt = ((tx % maxTile) + maxTile) % maxTile;
                if (ty < 0 || ty >= maxTile) continue;
                
                int scrX = w / 2 + (int) ((tx - ctx) * ts);
                int scrY = h / 2 + (int) ((ty - cty) * ts);

                String key = zoom + "/" + xt + "/" + ty;
                BufferedImage img = tileCache.get(key);

                if (img == null) {
                    // Irudia kaxean ez badago, hari bati eskatu deskargatzeko
                    final int fxt = xt, fyt = ty, fz = zoom;
                    final String fk = key;
                    tileLoader.submit(() -> {
                        if (!tileCache.containsKey(fk)) {
                            BufferedImage t = loadTile(fz, fxt, fyt);
                            if (t != null) {
                                tileCache.put(fk, t);
                                SwingUtilities.invokeLater(this::repaint);
                            }
                        }
                    });
                } else {
                    g2.drawImage(img, scrX, scrY, ts, ts, null);
                }
            }
        }
    }

    /**
     * loadTile(): CartoDB zerbitzaritik mapa irudi bat deskargatu.
     */
    private BufferedImage loadTile(int z, int x, int y) {
        try {
            String urlStr = "https://basemaps.cartocdn.com/rastertiles/voyager/" + z + "/" + x + "/" + y + ".png";
            HttpURLConnection con = (HttpURLConnection) new URL(urlStr).openConnection();
            con.setRequestProperty("User-Agent", "Mozilla/5.0 PakAG");
            con.setConnectTimeout(2000);
            if (con.getResponseCode() == 200) return ImageIO.read(con.getInputStream());
        } catch (Exception e) {}
        return null;
    }

    /**
     * drawMarkers(): Pakete bakoitzeko zirkulu koloretsu bat marraztu koordenatuetan.
     */
    private void drawMarkers(Graphics2D g2) {
        for (Pakete p : paquetes) {
            if (p.getEstado().equalsIgnoreCase("Entregatuta")) continue;
            double[] ll = geoCache.get(p.getDestino());
            if (ll != null) {
                Point pt = latLonToScreen(ll[0], ll[1]);
                Color fill = p.getEstado().equals("Biltegian") ? new Color(0xFF9800) : new Color(0x2196F3);
                
                int r = (p == hoveredPaq) ? 10 : 7; // Handitu sagua gainean badago
                g2.setColor(fill);
                g2.fillOval(pt.x - r, pt.y - r, r * 2, r * 2);
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(2f));
                g2.drawOval(pt.x - r, pt.y - r, r * 2, r * 2);
            }
        }
    }

    /**
     * drawLegend(): Beheko aldean koloreen esanahia azaltzen duen koadrotxoa.
     */
    private void drawLegend(Graphics2D g2) {
        int x = 10, y = getHeight() - 55;
        g2.setColor(new Color(255, 255, 255, 220));
        g2.fillRoundRect(x - 5, y - 5, 120, 50, 10, 10);
        g2.setFont(new Font("Segoe UI", Font.BOLD, 10));
        
        g2.setColor(new Color(0xFF9800)); g2.fillOval(x, y + 5, 10, 10);
        g2.setColor(Color.DARK_GRAY); g2.drawString("Biltegian", x + 15, y + 14);
        
        g2.setColor(new Color(0x2196F3)); g2.fillOval(x, y + 25, 10, 10);
        g2.setColor(Color.DARK_GRAY); g2.drawString("Bidean", x + 15, y + 34);
    }

    /**
     * drawTooltip(): Markatzaile baten gainean jartzean paketearen helbidea erakutsi.
     */
    private void drawTooltip(Graphics2D g2) {
        if (hoveredPaq == null || tooltipPt == null) return;
        String txt = hoveredPaq.getId() + ": " + hoveredPaq.getDestino();
        g2.setFont(new Font("Segoe UI", Font.BOLD, 11));
        int tw = g2.getFontMetrics().stringWidth(txt);
        
        g2.setColor(new Color(0, 0, 0, 180));
        g2.fillRoundRect(tooltipPt.x + 12, tooltipPt.y - 25, tw + 10, 20, 5, 5);
        g2.setColor(Color.WHITE);
        g2.drawString(txt, tooltipPt.x + 17, tooltipPt.y - 11);
    }

    // --- MATH UTILS (Mercator Proiekzioa) ---
    private double lonToTileX(double lon) { return (lon + 180.0) / 360.0 * (1 << zoom); }
    private double latToTileY(double lat) {
        double r = Math.toRadians(lat);
        return (1.0 - Math.log(Math.tan(r) + 1.0 / Math.cos(r)) / Math.PI) / 2.0 * (1 << zoom);
    }
    
    /**
     * latLonToScreen(): Koordenatu geografikoak pantailako pixel bihurtzen ditu.
     */
    private Point latLonToScreen(double lat, double lon) {
        int sx = (int) ((lonToTileX(lon) - lonToTileX(centerLon)) * 256) + getWidth() / 2;
        int sy = (int) ((latToTileY(lat) - latToTileY(centerLat)) * 256) + getHeight() / 2;
        return new Point(sx, sy);
    }
}