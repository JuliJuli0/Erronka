package pakag;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * HISTORIALAREN PANELA:
 * Sistemako gertaera eta mugimendu guztiak ikusteko panela.
 * Paketeen egoera aldaketak eta langileen ekintzak erregistratzen ditu.
 */
public class HistorialaPanela extends JPanel {

    // --- DISEINUAREN KONSTANTEAK (Koloreak eta estiloak) ---
    private final Color BG           = new Color(0xf8fafc);
    private final Color TEXT_DARK    = new Color(0x1e293b);
    private final Color TEXT_MUTED   = new Color(0x64748b);
    private final Color WHITE        = Color.WHITE;
    private final Color BORDER_COLOR = new Color(0xe2e8f0);

    // --- OSAGAI GRAFIKOAK ---
    private JTable table;
    private DefaultTableModel model;
    private TableRowSorter<DefaultTableModel> sorter;
    private JComboBox<String> filterLangilea;
    private DataStore dataStore;

    /**
     * Eraikitzailea: Panela hasieratu eta datuak kargatzen ditu.
     */
    public HistorialaPanela(DataStore dataStore) {
        this.dataStore = dataStore;
        setLayout(new BorderLayout());
        setBackground(BG);
        build();
    }

    /**
     * Interfazearen egitura eraikitzen du (Izenburua, Filtroak eta Taula).
     */
    private void build() {
        // Kontenedore nagusia marjinekin
        JPanel mainContent = new JPanel(new BorderLayout(0, 12));
        mainContent.setBackground(BG);
        mainContent.setBorder(new EmptyBorder(20, 20, 20, 20));

        // 1. IZENBURUA ETA AZPITITULUA
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.setOpaque(false);
        
        JLabel title = new JLabel("Historiala");
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setForeground(TEXT_DARK);
        
        JLabel subtitle = new JLabel("Langile zein paketeen mugimenduak ikusi");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitle.setForeground(TEXT_MUTED);
        
        titlePanel.add(title);
        titlePanel.add(subtitle);
        mainContent.add(titlePanel, BorderLayout.NORTH);

        // 2. ERDIKO PANELA (Filtroak + Taula)
        JPanel centerPanel = new JPanel(new BorderLayout(0, 10));
        centerPanel.setOpaque(false);

        // FILTROEN BARRA (Zuriz, lerro baten moduan)
        JPanel filterWrap = new JPanel(new BorderLayout());
        filterWrap.setBackground(WHITE);
        filterWrap.setBorder(new LineBorder(BORDER_COLOR));

        // --- EZKERREKO FILTROAK (Langilea + Bilatu + Garbitu) ---
        // Elementu guztiak elkarrekin agertzeko "Langilea" hautatzailearen ondoan
        JPanel leftFilters = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        leftFilters.setOpaque(false);

        List<String> langileaOpts = new ArrayList<>();
        langileaOpts.add("-- Guztiak --");
        
        // Langileak (banatzaileak soilik) kargatu JComboBox-ean
        for (Banatzailea r : dataStore.getRepartidores()) {
            if ("banatzailea".equalsIgnoreCase(r.getRola())) {
                langileaOpts.add(r.getIzena() + " " + r.getAbizena());
            }
        }
        filterLangilea = new JComboBox<>(langileaOpts.toArray(new String[0]));

        // Filtroen osagaiak gehitu
        leftFilters.add(makeLabel("Langilea:")); 
        leftFilters.add(filterLangilea);

        // BILATU BOTOIA: Taula iragazteko
        JButton searchBtn = Colores.accentButton("Bilatu");
        searchBtn.addActionListener(e -> aplicarFiltros());
        leftFilters.add(searchBtn);

        // GARBITU BOTOIA: Filtroak kentzeko eta dena berriz erakusteko
        JButton clearBtn = Colores.neutralButton("Garbitu");
        clearBtn.addActionListener(e -> {
            filterLangilea.setSelectedIndex(0);
            sorter.setRowFilter(null);
            cargarDatos();
        });
        leftFilters.add(clearBtn);

        // --- ESKUINEKO BOTOIA (Ezabatu soilik) ---
        // Ekintza arriskutsua denez, bereizita mantentzen dugu eskuinean
        JPanel rightFilters = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        rightFilters.setOpaque(false);

        JButton deleteBtn = Colores.dangerButton("🗑 Ezabatu Historiala");
        deleteBtn.addActionListener(e -> {
            // Berrespen leihoa (Confirm Dialog)
            Object[] aukerak = {"BAI", "EZ"};
            int confirm = JOptionPane.showOptionDialog(
                this,
                "Ziur zaude historial osoa ezabatu nahi duzula?",
                "Kontuz - Ekintza Iraganezina",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE,
                null,
                aukerak,
                aukerak[1]
            );
            
            if (confirm == JOptionPane.YES_OPTION) {
                dataStore.clearHistorial(); // Datuak ezabatu
                cargarDatos();              // Taula freskatu
            }
        });
        rightFilters.add(deleteBtn);

        // Filtroen barra osatu
        filterWrap.add(leftFilters,  BorderLayout.WEST);
        filterWrap.add(rightFilters, BorderLayout.EAST);
        centerPanel.add(filterWrap, BorderLayout.NORTH);

        // 3. TAULA ETA SCROLL-A
        String[] cols = {"ID", "Pakete ID", "Langilea", "Azalpena", "Data/Ordua"};
        model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        
        table  = KontrolPanela.buildStyledTable(model);
        sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter); // Bilaketak eta ordenazioa ahalbidetu
        cargarDatos();

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(new LineBorder(BORDER_COLOR));
        centerPanel.add(tableScroll, BorderLayout.CENTER);

        mainContent.add(centerPanel, BorderLayout.CENTER);
        add(mainContent);
    }

    /**
     * Datuak kargatzen ditu DataStore-tik eta taulan erakusten ditu.
     */
    public void cargarDatos() {
        model.setRowCount(0);
        List<String[]> rows = dataStore.getHistorial();
        for (String[] row : rows) {
            model.addRow(row);
        }
    }

    /**
     * Hautatutako langilearen arabera taula iragazten du.
     */
    private void aplicarFiltros() {
        if (filterLangilea.getSelectedIndex() > 0) {
            // 2. zutabean (Langilea) bilaketa egin aukeratutako testuarekin
            sorter.setRowFilter(RowFilter.regexFilter((String) filterLangilea.getSelectedItem(), 2));
        } else {
            sorter.setRowFilter(null); // Filtroa kendu
        }
    }

    /**
     * Etiketa txikiak sortzeko laguntzailea.
     */
    private JLabel makeLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 11));
        l.setForeground(TEXT_MUTED);
        return l;
    }
    
    /**
     * DataStore-a eguneratzeko metodoa (beharrezkoa bada).
     */
    public void setDataStore(DataStore newData) {
        this.dataStore = newData;
        this.cargarDatos();
    }
}