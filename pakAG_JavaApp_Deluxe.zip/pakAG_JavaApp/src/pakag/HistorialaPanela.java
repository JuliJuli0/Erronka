package pakag;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * HISTORIALAREN PANELA:
 * Sistemako gertaera eta mugimendu guztiak ikusteko panela.
 * Paketeen egoera aldaketak eta langileen ekintzak erregistratzen ditu.
 */
public class HistorialaPanela extends JPanel {

    // --- DISEINUAREN KONSTANTEAK ---
    private final Color BG           = new Color(0xf8fafc); // Atzealde argia
    private final Color TEXT_DARK    = new Color(0x1e293b); // Testu nabarmena
    private final Color TEXT_MUTED   = new Color(0x64748b); // Azpitituluak
    private final Color WHITE        = Color.WHITE;
    private final Color BORDER_COLOR = new Color(0xe2e8f0);

    // --- OSAGAI GRAFIKOAK ---
    private JTable table;                               // Historialaren taula
    private DefaultTableModel model;                    // Taularen datu-eredua
    private TableRowSorter<DefaultTableModel> sorter;   // Bilaketak/Filtroak egiteko mekanismoa
    private JComboBox<String> filterLangilea;           // Langileen araberako sukurtsala
    private DataStore dataStore;                        // Datu-baserako sarbidea

    /**
     * Eraikitzailea: Panela hasieratu eta datuak kargatzen ditu.
     * @param dataStore Datuen biltegia.
     */
    public HistorialaPanela(DataStore dataStore) {
        this.dataStore = dataStore;
        setLayout(new BorderLayout());
        setBackground(BG);
        build();
    }

    /**
     * Interfazearen egitura eraikitzen du (Izenburua, Filtroak eta Taula).
     */
    private void build() {
        // Kontenedore nagusia marjinekin
        JPanel mainContent = new JPanel(new BorderLayout(0, 12));
        mainContent.setBackground(BG);
        mainContent.setBorder(new EmptyBorder(20, 20, 20, 20));

        // 1. IZENBURUA ETA AZPITITULUA
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.setOpaque(false);
        
        JLabel title = new JLabel("Historiala");
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setForeground(TEXT_DARK);
        
        JLabel subtitle = new JLabel("Langile zein paketeen mugimenduak ikusi");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitle.setForeground(TEXT_MUTED);
        
        titlePanel.add(title);
        titlePanel.add(subtitle);
        mainContent.add(titlePanel, BorderLayout.NORTH);

        // 2. ERDIKO PANELA (Filtroak + Taula)
        JPanel centerPanel = new JPanel(new BorderLayout(0, 10));
        centerPanel.setOpaque(false);

        // FILTROEN BARRA (Zuriz, lerro baten moduan)
        JPanel filterWrap = new JPanel(new BorderLayout());
        filterWrap.setBackground(WHITE);
        filterWrap.setBorder(new LineBorder(BORDER_COLOR));

        // Ezkerreko filtroak (Langilea aukeratzeko)
        JPanel leftFilters = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        leftFilters.setOpaque(false);

        List<String> langileaOpts = new ArrayList<>();
        langileaOpts.add("-- Guztiak --");
        
        // Filtroan soilik "banatzailea" rola dutenak sartu
        for (Banatzailea r : dataStore.getRepartidores()) {
            if ("banatzailea".equalsIgnoreCase(r.getRola())) {
                langileaOpts.add(r.getIzena() + " " + r.getAbizena());
            }
        }
        filterLangilea = new JComboBox<>(langileaOpts.toArray(new String[0]));

        leftFilters.add(makeLabel("Langilea:")); 
        leftFilters.add(filterLangilea);

        // Eskuineko botoiak (Bilatu, Garbitu, Ezabatu)
        JPanel rightFilters = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        rightFilters.setOpaque(false);

        JButton searchBtn = Colores.accentButton("Bilatu");
        searchBtn.addActionListener(e -> aplicarFiltros());

        JButton clearBtn = Colores.neutralButton("Garbitu");
        clearBtn.addActionListener(e -> {
            filterLangilea.setSelectedIndex(0); // Filtroa hasieratu
            sorter.setRowFilter(null);          // Taulako filtroa kendu
            cargarDatos();                      // Datuak freskatu
        });

        // HISTORIALA EZABATZEKO BOTOIA (Gorriz)
        JButton deleteBtn = Colores.dangerButton("🗑 Ezabatu Historiala");
        deleteBtn.addActionListener(e -> {
            // Berrespen leiho pertsonalizatua euskaraz
            Object[] aukerak = {"BAI", "EZ"};
            int confirm = JOptionPane.showOptionDialog(
                this,
                "Ziur zaude historial osoa ezabatu nahi duzula?",
                "Kontuz - Ekintza Iraganezina",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE,
                null,
                aukerak,
                aukerak[1] // "EZ" da botoi lehenetsia arriskuak saihesteko
            );
            
            if (confirm == JOptionPane.YES_OPTION) {
                dataStore.clearHistorial(); // Datu-basetik ezabatu
                cargarDatos();              // Taula hustu
            }
        });
        
        rightFilters.add(searchBtn);
        rightFilters.add(clearBtn);
        rightFilters.add(deleteBtn);

        filterWrap.add(leftFilters,  BorderLayout.WEST);
        filterWrap.add(rightFilters, BorderLayout.EAST);
        centerPanel.add(filterWrap, BorderLayout.NORTH);

        // 3. TAULA ETA SCROLL-A
        String[] cols = {"ID", "Pakete ID", "Langilea", "Azalpena", "Data/Ordua"};
        model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        
        table  = KontrolPanela.buildStyledTable(model);
        sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter); // Ordenazioa eta filtroak ahalbidetu
        cargarDatos();

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(new LineBorder(BORDER_COLOR));
        centerPanel.add(tableScroll, BorderLayout.CENTER);

        mainContent.add(centerPanel, BorderLayout.CENTER);
        add(mainContent);
    }

    /**
     * Taula kargatzen du DataStore-tik lortutako historial erregistroekin.
     */
    public void cargarDatos() {
        model.setRowCount(0); // Taula hustu
        List<String[]> rows = dataStore.getHistorial();
        for (String[] row : rows) {
            model.addRow(row);
        }
    }

    /**
     * RegexFilter erabiliz, taulan aukeratutako langilearen erregistroak soilik erakusten ditu.
     */
    private void aplicarFiltros() {
        if (filterLangilea.getSelectedIndex() > 0) {
            // 2. zutabean (Langilea) bilaketa egin aukeratutako testuarekin
            sorter.setRowFilter(RowFilter.regexFilter((String) filterLangilea.getSelectedItem(), 2));
        } else {
            sorter.setRowFilter(null); // Denak erakutsi
        }
    }

    /**
     * Etiketa txikiak eta grisak sortzeko laguntzailea (UI koherentziarako).
     */
    private JLabel makeLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 11));
        l.setForeground(TEXT_MUTED);
        return l;
    }
    
    /**
     * Datu-iturria kanpotik aldatu eta panela freskatzeko.
     * @param newData DataStore berria.
     */
    public void setDataStore(DataStore newData) {
        this.dataStore = newData;
        this.cargarDatos();
    }
}