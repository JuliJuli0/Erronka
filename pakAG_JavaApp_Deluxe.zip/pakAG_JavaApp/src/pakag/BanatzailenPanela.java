package pakag;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;

/**
 * KLASAREN ARDURA:
 * BanatzailenPanela interfaze grafikoaren (GUI) osagaia da, langileen kudeaketaz arduratzen dena.
 * CRUD (Create, Read, Update, Delete) operazioak ahalbidetzen ditu taula baten bidez.
 */
public class BanatzailenPanela extends JPanel {

    // --- ATRIBUTU PRIBATUAK ---
    private DataStore data;             	// Datuen persistentzia kudeatzen duen objektua
    private DefaultTableModel tableModel; 	// Taularen egitura eta datuak definitzen dituena
    private JTable table;               	// Interfazean datuak erakusten dituen osagai bisuala

    /**
     * ERAIKITZAILEA: Panela hasieratzen du.
     * @param data Datu-iturria, langileen zerrenda atzitzeko.
     */
    public BanatzailenPanela(DataStore data) {
        this.data = data;
        
        // Panelaren diseinu nagusia ezarri
        setLayout(new BorderLayout());
        setBackground(Colores.BG); // Kolore korporatiboa erabili
        
        // Kanpoko marjina (padding) gehitu panelari
        setBorder(new EmptyBorder(16, 20, 16, 20));
        
        // Osagai guztiak eraiki eta kargatu
        build();
    }

    /**
     * build(): Interfazearen hezurdura eraikitzen duen metodo nagusia.
     * Goiko barra, botoiak eta taula biltzen dituen "card" egitura sortzen ditu.
     */
    private void build() {
        // 1. GOIKO BARRA: Titulua eta Ekintza botoiak biltzen ditu
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false); // Atzealdeko kolorea ikusteko
        topBar.setBorder(new EmptyBorder(0, 0, 12, 0));

        // Titulua diseinatu
        JLabel title = new JLabel("👥 Langileen Kudeaketa");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(Colores.TEXT_DARK);

        // Botoien kontenedorea (eskuinean lerrokatuta)
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);
        
        JButton btnAdd  = Colores.accentButton("+ Langile Berria");
        JButton btnEdit = Colores.neutralButton("✏ Editatu");
        JButton btnDel  = Colores.dangerButton("🗑 Ezabatu");
        
        buttons.add(btnAdd);
        buttons.add(btnEdit);
        buttons.add(btnDel);

        topBar.add(title, BorderLayout.WEST);
        topBar.add(buttons, BorderLayout.EAST);

        // 2. TAULAREN KONFIGURAZIOA
        // Zutabeen izenburuak definitu
        String[] cols = {"NAN", "Izena", "Abizena", "Telefonoa", "Erabiltzailea", "Pasahitza", "Rola", "Helbidea"};
        
        // tableModel: Gelaxkak zuzenean editatzea desgaitzen dugu isCellEditable false itzuliz
        tableModel = new DefaultTableModel(cols, 0) {
            @Override 
            public boolean isCellEditable(int r, int c) { return false; }
        };
        
        // Taula estilizatu (KontrolPanela-n definitutako estiloarekin)
        table = KontrolPanela.buildStyledTable(tableModel);
        refreshTable(); // Hasierako datuak kargatu

        // Taulari scroll-a gehitu (erregistro asko balira ere mugitzeko)
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(Colores.BORDER_COLOR, 1, true));
        sp.getViewport().setBackground(Color.WHITE);

        // 3. TXARTEL ESTILOA (CARD): Taula zuri baten gainean jartzeko efektua
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.add(Colores.sectionHeader("LANGILEEN ZERRENDA"), BorderLayout.NORTH);
        card.add(sp, BorderLayout.CENTER);

        // Osagai nagusiak panelera gehitu
        add(topBar, BorderLayout.NORTH);
        add(card, BorderLayout.CENTER);

        // --- EKINTZEN LOGIKA (Listeners) ---

        // Gehitu: Leiho berri bat irekitzen du langile datuak sartzeko
        btnAdd.addActionListener(e -> showAddDialog());

        // Editatu: Hautatutako lerroaren datuak editatzeko leihoa ireki
        btnEdit.addActionListener(e -> {
            int row = table.getSelectedRow();
            // VALIDAZIOA: Ez badago ezer hautatuta, abisua eman eta eten (return)
            if (row < 0) { 
                showWarning("Hautatu langile bat lehenik."); 
                return; // 'break' ez da beharrezkoa return-ek metodoa hemen mozten duelako
            }
            showEditDialog(row);
        });
        
        // Ezabatu: Hautatutako langilea sistematik kentzeko
        btnDel.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { 
                showWarning("Hautatu langile bat lehenik."); 
                return; 
            }

            // Baieztapen mezua euskara hutsean
            Object[] aukerak = {"BAI", "EZ"};
            int confirm = JOptionPane.showOptionDialog(
                this, 
                "Ziur zaude langile hau ezabatu nahi duzula?", 
                "Kontuz - Ezabatu", 
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.WARNING_MESSAGE, 
                null, 
                aukerak, 
                aukerak[1] // Fokusua "EZ" botoian jarri arriskuak ekiditeko
            );

            // "BAI" sakatu bada (indizea 0), datu-iturburutik kendu
            if (confirm == JOptionPane.YES_OPTION) {
                data.removeRepartidor(row);
                refreshTable(); // Interfazea eguneratu
            }
        });
    }

    /**
     * refreshTable(): Taulako edukia garbitu eta DataStore-tik datu berriak kargatzen ditu.
     */
    public void refreshTable() {
        tableModel.setRowCount(0); // Taula hustu
        for (Banatzailea r : data.getRepartidores()) {
            // Lerro bakoitza gehitu atributu guztiekin
            tableModel.addRow(new Object[]{
                r.getId(), r.getIzena(), r.getAbizena(), r.getTelefonoa(),
                r.getErabiltzailea(), r.getPasahitza(), r.getRola(), r.getHelbidea()
            });
        }
    }

    /**
     * showAddDialog(): Langile berriak sortzeko modal leihoa.
     */
    private void showAddDialog() {
        JDialog dialog = createDialog("Langile Berria");
        
        // Inprimakiko testu-eremuak (Textfields)
        JTextField fNan = new JTextField();
        JTextField fIzena = new JTextField();
        JTextField fAbizena = new JTextField();
        JTextField fTele = new JTextField();
        JTextField fUser = new JTextField();
        JTextField fPass = new JTextField(); 
        JComboBox<String> fRol = new JComboBox<>(new String[]{"Banatzailea", "Kudeatzailea"});
        JTextField fHelbidea = new JTextField();

        // Formularioa eraiki (Lable + Field bikoteak)
        JPanel form = buildForm(
            new String[]{"NAN", "Izena", "Abizena", "Telefonoa", "Erabiltzailea", "Pasahitza", "Rola", "Helbidea"},
            new JComponent[]{fNan, fIzena, fAbizena, fTele, fUser, fPass, fRol, fHelbidea}
        );

        JButton save = Colores.accentButton("Gorde");
        save.addActionListener(e -> {
            // Balioak jaso eta objektu berria sortu
            Banatzailea n = new Banatzailea(fNan.getText(), fIzena.getText(), fAbizena.getText(), 
                                         fUser.getText(), fPass.getText(), 
                                         (String)fRol.getSelectedItem(), fHelbidea.getText());
            n.setTelefonoa(fTele.getText());
            
            data.addRepartidor(n); // Datu basean/zerrendan gorde
            refreshTable();        // Pantaila eguneratu
            dialog.dispose();      // Leihoa itxi
        });
        
        showDialog(dialog, form, save);
    }

    /**
     * showEditDialog(): Hautatutako langile baten datuak aldatzeko.
     * @param row Editatu nahi den erregistroaren indizea.
     */
    private void showEditDialog(int row) {
        // Datu-iturburutik hautatutako langilea lortu
        Banatzailea r = data.getRepartidores().get(row);
        JDialog dialog = createDialog("Editatu Langilea");
        
        // Testu-eremuak kargatu uneko datuekin
        JTextField fNan = new JTextField(r.getId()); 
        fNan.setEditable(false); // IDa (NAN) ezin da aldatu behin sortuta
        
        JTextField fIzena = new JTextField(r.getIzena());
        JTextField fAbizena = new JTextField(r.getAbizena());
        JTextField fTele = new JTextField(r.getTelefonoa());
        JTextField fUser = new JTextField(r.getErabiltzailea());
        JTextField fPass = new JTextField(r.getPasahitza()); 
        JComboBox<String> fRol = new JComboBox<>(new String[]{"Banatzailea", "Kudeatzailea"});
        fRol.setSelectedItem(r.getRola());
        JTextField fHelbidea = new JTextField(r.getHelbidea());

        JPanel form = buildForm(
            new String[]{"NAN", "Izena", "Abizena", "Telefonoa", "Erabiltzailea", "Pasahitza", "Rola", "Helbidea"},
            new JComponent[]{fNan, fIzena, fAbizena, fTele, fUser, fPass, fRol, fHelbidea}
        );

        JButton save = Colores.accentButton("Gorde");
        save.addActionListener(e -> {
            // Objektuaren atributuak eguneratu field-etako testuarekin
            r.setIzena(fIzena.getText());
            r.setAbizena(fAbizena.getText());
            r.setTelefonoa(fTele.getText());
            r.setErabiltzailea(fUser.getText());
            r.setPasahitza(fPass.getText());
            r.setRola((String)fRol.getSelectedItem());
            r.setHelbidea(fHelbidea.getText());
            
            data.updateRepartidor(r); // Aldaketak BDan finkatu
            refreshTable();           // Taula berritu
            dialog.dispose();         // Leihoa itxi
        });
        
        showDialog(dialog, form, save);
    }

    // --- LAGUNTZA METODOAK (Helper Methods) ---

    /**
     * createDialog(): Leiho modal bat sortzeko oinarrizko konfigurazioa.
     */
    private JDialog createDialog(String t) {
        JDialog d = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), t, true);
        d.setSize(450, 550); // Tamaina doituta
        d.setLocationRelativeTo(this); // Pantailaren erdian jarri
        return d;
    }

    /**
     * buildForm(): GridBagLayout erabiliz, etiketa eta testu-eremuak lerrokatzen ditu.
     */
    private JPanel buildForm(String[] labels, JComponent[] fields) {
        JPanel p = new JPanel(new GridBagLayout()); 
        p.setBackground(Color.WHITE);
        GridBagConstraints gc = new GridBagConstraints(); 
        gc.insets = new Insets(8, 15, 8, 15); // Elementuen arteko tartea
        
        for (int i = 0; i < labels.length; i++) {
            // Ezkerraldean: Etiketa (Label)
            gc.gridx = 0; gc.gridy = i; gc.anchor = GridBagConstraints.WEST; 
            JLabel lbl = new JLabel(labels[i] + ":");
            lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
            p.add(lbl, gc);
            
            // Eskuinaldean: Testu-eremua (Field)
            gc.gridx = 1; gc.fill = GridBagConstraints.HORIZONTAL; gc.weightx = 1.0; 
            p.add(fields[i], gc);
        }
        return p;
    }

    /**
     * showDialog(): Inprimakia eta beheko botoiak (Gorde/Utzi) leihoan integratu eta erakutsi.
     */
    private void showDialog(JDialog d, JPanel f, JButton s) {
        JPanel btnP = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        btnP.setBackground(new Color(0xf5f7f9)); // Botoien barrako kolore berezia
        
        JButton c = Colores.neutralButton("Utzi"); 
        c.addActionListener(e -> d.dispose()); // Utzi sakatzean leihoa itxi besterik ez
        
        btnP.add(c); 
        btnP.add(s);
        
        d.add(f, BorderLayout.CENTER); 
        d.add(btnP, BorderLayout.SOUTH);
        d.setVisible(true); // Leihoa erakutsi (modala denez, aplikazioa hemen geldituko da)
    }

    /**
     * showWarning(): Errore edo abisu mezuak leiho bidez erakusteko.
     */
    private void showWarning(String m) { 
        JOptionPane.showMessageDialog(this, m, "Abisua", JOptionPane.WARNING_MESSAGE); 
    }
    
    /**
     * setDataStore(): Kanpotik datu-iturburu berri bat esleitzeko aukera ematen du.
     */
    public void setDataStore(DataStore newData) {
        this.data = newData; 
        this.refreshTable(); 
    }
}