package pakag;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

/**
 * 📊 KONTROL PANELA (Dashboard):
 * Aplikazioaren panel nagusia da. Bertan, logistikaren laburpen orokorra,
 * azken paketeen zerrenda eta mapa interaktiboa erakusten dira.
 */
public class KontrolPanela extends JPanel {

    private DataStore data; // Datu-iturria metriken balioak kalkulatzeko
    
    // --- KANPOKO ERABILPENERAKO ELEMENTUAK ---
    // MainPanel-etik atzitu ahal izateko (adibidez, datuak berritzeko)
    private JTable tableAzkenPaketeak;
    private MapCanvas mapaPanel; 

    /**
     * Eraikitzailea: Panela hasieratu eta diseinuaren egitura definitu.
     * @param data Datuen biltegia.
     */
    public KontrolPanela(DataStore data) {
        this.data = data;
        // Elementuak bertikalean pilatzeko diseinua (Metriken kaxa + Beheko sekzioa)
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Colores.BG);
        setBorder(new EmptyBorder(16, 20, 16, 20));
        rebuild();
    }

    /**
     * rebuild(): Panela guztiz berreraikitzen du. 
     * Erabilgarria datu-basean aldaketa handiak egon direnean interfazea freskatzeko.
     */
    public void rebuild() {
        removeAll(); // Oraingo osagaiak kendu
        add(buildMetricsSection());  // Metrika kaxak gehitu
        add(Box.createVerticalStrut(14)); // Tarte bat gehitu
        add(buildBottomSection());   // Taula eta mapa gehitu
        revalidate();
        repaint();
    }

    // --- GETTERS (Beste klase batzuek osagaiak manipulatzeko) ---
    public JTable getTableAzkenPaketeak() { return tableAzkenPaketeak; }
    public MapCanvas getMapaPanel()       { return mapaPanel; }

    /**
     * buildMetricsSection(): Goiko laburpen kaxak eraikitzen ditu (Madrila, Biltegia, etab.)
     * @return Laburpen panel osatua.
     */
    private JPanel buildMetricsSection() {
        JPanel section = new JPanel(new BorderLayout());
        section.setOpaque(false);
        // Panelak altuera finkoa izateko
        section.setMaximumSize(new Dimension(Integer.MAX_VALUE, 115));

        section.add(Colores.sectionHeader("LABURPEN LOGISTIKOA"), BorderLayout.NORTH);

        // Grid bat erabiliz metrika bakoitza zutabe batean jartzeko
        JPanel box = new JPanel(new GridLayout(1, 7, 0, 0));
        box.setBackground(Colores.WHITE);
        box.setBorder(new CompoundBorder(
            new MatteBorder(0,1,1,1, Colores.BORDER_COLOR),
            new EmptyBorder(12,16,12,16)
        ));

        // DATUEN KALKULUA (Stream-ak erabiliz egoeraren arabera sukurtsalak zenbatu)
        long totalRep   = data.getRepartidores().size();
        long enAlmacen  = data.getPaquetes().stream().filter(p -> p.getEstado().equals("Biltegian")).count();
        long enRuta     = data.getPaquetes().stream().filter(p -> p.getEstado().equals("Bidean")).count();
        long entregados = data.getPaquetes().stream().filter(p -> p.getEstado().equals("Entregatuta")).count();

        // Metrika bakoitza bere ikono eta testuarekin gehitu
        box.add(buildMetric("🚚", String.valueOf(totalRep), "BANATZAILEAK"));
        box.add(buildDivider());
        box.add(buildMetric("📦", String.valueOf(enAlmacen), "BILTEGIAN"));
        box.add(buildDivider());
        box.add(buildMetric("📍", String.valueOf(enRuta), "BIDEAN"));
        box.add(buildDivider());
        box.add(buildMetric("✓", String.valueOf(entregados), "ENTREGATUTA"));

        section.add(box, BorderLayout.CENTER);
        return section;
    }

    /**
     * buildMetric(): Metrika indibidual bat diseinatzen du (Ikonoa + Balioa + Etiketa).
     */
    private JPanel buildMetric(String icon, String value, String label) {
        JPanel m = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        m.setOpaque(false);

        // Ikonoaren atzealde biribildua margotzeko klase anonimoa
        JLabel iconLbl = new JLabel(icon, SwingConstants.CENTER) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Colores.ICON_BG);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                super.paintComponent(g);
            }
        };
        iconLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 18));
        iconLbl.setPreferredSize(new Dimension(44,44));

        JPanel textBox = new JPanel();
        textBox.setLayout(new BoxLayout(textBox, BoxLayout.Y_AXIS));
        textBox.setOpaque(false);
        
        JLabel valLbl = new JLabel(value);
        valLbl.setFont(new Font("Segoe UI", Font.BOLD, 22));
        valLbl.setForeground(Colores.TEXT_DARK);
        
        JLabel lblLbl = new JLabel(label);
        lblLbl.setFont(new Font("Segoe UI", Font.BOLD, 9));
        lblLbl.setForeground(Colores.TEXT_MUTED);
        
        textBox.add(valLbl);
        textBox.add(lblLbl);

        m.add(iconLbl);
        m.add(textBox);
        return m;
    }

    /** @return Banatzaile bertikal fin bat metrikak bereizteko. */
    private JSeparator buildDivider() {
        JSeparator s = new JSeparator(SwingConstants.VERTICAL);
        s.setForeground(Colores.BORDER_COLOR);
        s.setPreferredSize(new Dimension(1,60));
        return s;
    }

    /**
     * buildBottomSection(): Taula eta Mapa horizontalki lerrokatzen ditu.
     */
    private JPanel buildBottomSection() {
        JPanel bottom = new JPanel(new BorderLayout(14,0));
        bottom.setOpaque(false);
        bottom.add(buildTableSection(), BorderLayout.CENTER); // Taula ezkerrean (edo erdian zabaldu)
        bottom.add(buildMapSection(), BorderLayout.EAST);     // Mapa eskuinean
        return bottom;
    }

    /**
     * buildTableSection(): Paketeen zerrenda erakusten duen taula eraiki.
     */
    private JPanel buildTableSection() {
        JPanel section = new JPanel(new BorderLayout());
        section.setBackground(Colores.WHITE);
        section.setBorder(new LineBorder(Colores.BORDER_COLOR,1,true));

        section.add(Colores.sectionHeader("AZKEN PAKETEAK"), BorderLayout.NORTH);

        String[] cols = {"Pakete ID", "Bezeroa", "Helbidea", "Banatzailea", "Egoera"};
        List<Pakete> paquetes = data.getPaquetes();
        Object[][] rows = new Object[paquetes.size()][5];
        
        // List-etik Array-ra pasa taulak behar duen formatuan
        for (int i = 0; i < paquetes.size(); i++) {
            Pakete p = paquetes.get(i);
            rows[i] = new Object[]{p.getId(), p.getCliente(), p.getDestino(), p.getRepartidor(), p.getEstado()};
        }

        DefaultTableModel model = new DefaultTableModel(rows, cols) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        
        tableAzkenPaketeak = buildStyledTable(model);

        JScrollPane sp = new JScrollPane(tableAzkenPaketeak);
        sp.setBorder(null);
        sp.getViewport().setBackground(Colores.WHITE);
        section.add(sp, BorderLayout.CENTER);
        return section;
    }

    /**
     * buildStyledTable(): JTable bati itxura modernoa ematen dion metodo estatikoa.
     * @param model Taularen datu-eredua.
     * @return Estilizatutako JTable-a.
     */
    public static JTable buildStyledTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setRowHeight(32);
        table.setShowVerticalLines(false);
        table.setGridColor(new Color(0xf0f2f5));
        table.setSelectionBackground(new Color(0xe8f4ff));
        table.setBackground(Colores.WHITE);
        table.setFillsViewportHeight(true);

        // Goiburukoaren diseinua
        JTableHeader th = table.getTableHeader();
        th.setFont(new Font("Segoe UI", Font.BOLD, 11));
        th.setBackground(new Color(0xf5f7f9));
        th.setForeground(new Color(0x555555));
        th.setBorder(new MatteBorder(0,0,1,0, Colores.BORDER_COLOR));
        th.setReorderingAllowed(false);

        // EGOERA ZUTABEA: "Badge" edo etiketa koloretsu gisa marraztu
        int lastCol = model.getColumnCount() - 1;
        table.getColumnModel().getColumn(lastCol).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val, boolean sel, boolean foc, int row, int col) {
                JPanel cell = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
                cell.setBackground(sel ? new Color(0xe8f4ff) : Colores.WHITE);
                if (val == null) return cell;
                
                String estado = val.toString();
                JLabel badge = new JLabel(estado) {
                    @Override protected void paintComponent(Graphics g) {
                        Graphics2D g2 = (Graphics2D)g;
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        
                        // Egoeraren araberako koloreak
                        Color bg = switch (estado) {
                            case "Biltegian"   -> new Color(0xFF9800);
                            case "Bidean"      -> new Color(0x2196F3);
                            case "Entregatuta" -> new Color(0x4CAF50);
                            default            -> new Color(0x94a3b8);
                        };
                        
                        g2.setColor(bg);
                        g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                        super.paintComponent(g);
                    }
                };
                badge.setFont(new Font("Segoe UI", Font.BOLD, 10));
                badge.setForeground(Color.WHITE);
                badge.setBorder(new EmptyBorder(3,10,3,10));
                cell.add(badge);
                return cell;
            }
        });

        // Beste zutabeei padding-a gehitu testua ertzetik urruntzeko
        DefaultTableCellRenderer paddedRenderer = new DefaultTableCellRenderer() {
            { setBorder(new EmptyBorder(0,10,0,10)); }
        };
        for (int i = 0; i < lastCol; i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(paddedRenderer);
        }

        return table;
    }

    /**
     * buildMapSection(): Mapa interaktiboa kokatzen den sekzioa eraiki.
     */
    private JPanel buildMapSection() {
        JPanel section = new JPanel(new BorderLayout());
        section.setBackground(Colores.WHITE);
        section.setPreferredSize(new Dimension(350, 0));
        section.setBorder(new LineBorder(Colores.BORDER_COLOR, 1, true));
        
        section.add(Colores.sectionHeader("MAPA INTERAKTIBOA"), BorderLayout.NORTH);
        
        mapaPanel = new MapCanvas();
        section.add(mapaPanel, BorderLayout.CENTER);
        
        return section;
    }
    
    /**
     * Datu-iturria eguneratu eta panela berritu.
     */
    public void setDataStore(DataStore newData) {
        this.data = newData; 
        this.rebuild();
    }
}