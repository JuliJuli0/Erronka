package pakag;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

/**
 * 📦 PAKETEEN PANELA:
 * Paketeen kudeaketa osoaz arduratzen den sekzioa (CRUD).
 * Pakete berriak gehitu, lehendik daudenak aldatu edo ezabatzeko aukera ematen du.
 */
public class PaketenPanela extends JPanel {

    private DataStore data;
    private DefaultTableModel tableModel;
    private JTable table;
    
    // Baliagarriak diren balio finkoak konboetarako
    private static final String[] ESTADOS = {"Biltegian", "Bidean", "Entregatuta"};
    private static final String[] TAMAINAS = {"txikia", "ertaina", "handia"};

    /**
     * Eraikitzailea: Panela hasieratu eta diseinuaren egitura nagusia marraztu.
     */
    public PaketenPanela(DataStore data) {
        this.data = data;
        setLayout(new BorderLayout());
        setBackground(Colores.BG);
        setBorder(new EmptyBorder(16,20,16,20));
        build();
    }

    /**
     * build(): Interfazearen elementuak (Goiko barra, botoiak eta taula) eraiki.
     */
    private void build() {
        // --- GOIKO BARRA (Izenburua eta Ekintzak) ---
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);
        topBar.setBorder(new EmptyBorder(0,0,12,0));

        JLabel title = new JLabel("📦 Paketeen Kudeaketa");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(Colores.TEXT_DARK);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);
        JButton btnAdd  = Colores.accentButton("+ Pakete Berria");
        JButton btnEdit = Colores.neutralButton("✏ Editatu");
        JButton btnDel  = Colores.dangerButton("🗑 Ezabatu");
        buttons.add(btnAdd); buttons.add(btnEdit); buttons.add(btnDel);

        topBar.add(title, BorderLayout.WEST);
        topBar.add(buttons, BorderLayout.EAST);

        // --- TAULA (Datuen erakusleihoa) ---
        String[] cols = {"ID", "Bezeroa", "Helbidea", "Langilea", "Tamaina", "Egoera"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        // KontrolPanela-ko estilo bera aplikatu koherentzia mantentzeko
        table = KontrolPanela.buildStyledTable(tableModel);
        refreshTable();

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(Colores.BORDER_COLOR, 1, true));
        sp.getViewport().setBackground(Colores.WHITE);

        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Colores.WHITE);
        card.add(Colores.sectionHeader("PAKETEEN ZERRENDA"), BorderLayout.NORTH);
        card.add(sp, BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(card, BorderLayout.CENTER);

        // --- EKINTZEN LOGIKA (Botoiak) ---
        
        btnAdd.addActionListener(e -> showAddDialog());
        
        btnEdit.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showWarning("Hautatu pakete bat lehenik."); return; }
            showEditDialog(row);
        });
        
        btnDel.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showWarning("Hautatu pakete bat lehenik."); return; }

            Object[] aukerak = {"BAI", "EZ"};
            int confirm = JOptionPane.showOptionDialog(this, 
                "Ziur zaude ezabatu nahi duzula?", "Ezabatu", 
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, 
                null, aukerak, aukerak[1]);

            if (confirm == JOptionPane.YES_OPTION) {
                data.removePaquete(row);
                refreshTable();
            }
        });
    }

    /**
     * refreshTable(): Taulako lerro guztiak ezabatu eta DataStore-ko datu berriekin bete.
     */
    public void refreshTable() {
        tableModel.setRowCount(0);
        for (Pakete p : data.getPaquetes()) {
            tableModel.addRow(new Object[]{
                p.getId(), p.getCliente(), p.getDestino(),
                p.getRepartidor(), p.getTamaina().name(), p.getEstado()
            });
        }
    }

    /**
     * showAddDialog(): Pakete berri bat sartzeko formulario leihoa ireki.
     */
    private void showAddDialog() {
        JDialog dialog = createDialog("Pakete berria gehitu");
        
        // ID-a automatikoki kalkulatu eta blokeatu
        JTextField fId = new JTextField(data.nextPaqueteId());
        fId.setEditable(false); fId.setBackground(new Color(0xf0f2f5));
        
        JTextField fCliente = new JTextField();
        JTextField fDestino = new JTextField();
        
        // Langileen hautatzailea (Bakarrik banatzaileak erakutsi)
        JComboBox<String> fRep = new JComboBox<>();
        fRep.addItem("Esleitu gabe");
        for (Banatzailea r : data.getRepartidores()) {
            if ("banatzailea".equalsIgnoreCase(r.getRola())) {
                fRep.addItem(r.getIzena() + " " + r.getAbizena() + " (" + r.getId() + ")");
            }
        }
        
        JComboBox<String> fTam = new JComboBox<>(TAMAINAS);
        JComboBox<String> fEst = new JComboBox<>(ESTADOS);

        JPanel form = buildForm(new String[]{"ID", "Bezeroa", "Helbidea", "Langilea", "Tamaina", "Egoera"},
            new JComponent[]{fId, fCliente, fDestino, fRep, fTam, fEst});

        JButton save = Colores.accentButton("Gorde");
        save.addActionListener(e -> {
            data.addPaquete(new Pakete(fId.getText(), fCliente.getText(), fDestino.getText(),
                (String)fRep.getSelectedItem(), (String)fEst.getSelectedItem(),
                Pakete.Tamaina.valueOf((String)fTam.getSelectedItem())));
            refreshTable(); 
            dialog.dispose();
        });
        showDialog(dialog, form, save);
    }

    /**
     * showEditDialog(): Hautatutako pakete baten datuak aldatzeko leihoa.
     */
    private void showEditDialog(int row) {
        Pakete p = data.getPaquetes().get(row);
        JDialog dialog = createDialog("Editatu: " + p.getId());

        JTextField fId = new JTextField(p.getId());
        fId.setEditable(false); 
        
        JTextField fCliente = new JTextField(p.getCliente());
        JTextField fDestino = new JTextField(p.getDestino());
        
        JComboBox<String> fRep = new JComboBox<>();
        fRep.addItem("Esleitu gabe");
        for (Banatzailea r : data.getRepartidores()) {
            if ("banatzailea".equalsIgnoreCase(r.getRola())) {
                String item = r.getIzena() + " " + r.getAbizena() + " (" + r.getId() + ")";
                fRep.addItem(item);
                // Aurretik zeukan langilea hautatu
                if (p.getRepartidor() != null && p.getRepartidor().contains(r.getId())) {
                    fRep.setSelectedItem(item);
                }
            }
        }
        
        JComboBox<String> fTam = new JComboBox<>(TAMAINAS);
        fTam.setSelectedItem(p.getTamaina().name());
        
        JComboBox<String> fEst = new JComboBox<>(ESTADOS);
        fEst.setSelectedItem(p.getEstado());

        JPanel form = buildForm(new String[]{"ID", "Bezeroa", "Helbidea", "Langilea", "Tamaina", "Egoera"},
            new JComponent[]{fId, fCliente, fDestino, fRep, fTam, fEst});

        JButton save = Colores.accentButton("Gorde");
        save.addActionListener(e -> {
            p.setCliente(fCliente.getText());
            p.setDestino(fDestino.getText());
            p.setRepartidor((String) fRep.getSelectedItem());
            p.setEstado((String) fEst.getSelectedItem());
            p.setTamaina(Pakete.Tamaina.valueOf((String) fTam.getSelectedItem()));
            
            data.updatePaquete(p); 
            refreshTable();
            dialog.dispose();
        });
        
        showDialog(dialog, form, save);
    }

    // --- UTILS (Elkarrizketa-leihoen diseinua sinpletzeko) ---

    private JDialog createDialog(String title) {
        JDialog d = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), title, true);
        d.setSize(440, 420); d.setLocationRelativeTo(this); return d;
    }

    private JPanel buildForm(String[] labels, JComponent[] fields) {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6,4,6,4); gc.anchor = GridBagConstraints.WEST;
        for (int i = 0; i < labels.length; i++) {
            gc.gridx=0; gc.gridy=i; form.add(new JLabel(labels[i]+":"), gc);
            gc.gridx=1; gc.fill=GridBagConstraints.HORIZONTAL; gc.weightx=1; form.add(fields[i], gc);
        }
        return form;
    }

    private void showDialog(JDialog d, JPanel f, JButton s) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton c = Colores.neutralButton("Utzi"); c.addActionListener(e->d.dispose());
        p.add(c); p.add(s);
        d.add(f, BorderLayout.CENTER); d.add(p, BorderLayout.SOUTH);
        d.setVisible(true);
    }

    private void showWarning(String msg) { JOptionPane.showMessageDialog(this, msg, "Abisua", 2); }
    
    /**
     * setDataStore(): Datuen biltegia berritzen du (adibidez, API-tik datu berriak ekartzean).
     */
    public void setDataStore(DataStore newData) {
        this.data = newData; 
        this.refreshTable(); 
    }
}