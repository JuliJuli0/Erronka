package pakag;

/**
 * PAKETE KLASEA:
 * Sistema barruan garraiatzen den unitate bakoitza errepresentatzen du.
 * Bidalketaren informazio guztia gordetzen duen datu-egitura da.
 */
public class Pakete {
    
    /**
     * Tamaina: Paketearen neurri fisikoak mugatzeko enumerazioa.
     * Datu-basean balio kontrolatuak egongo direla ziurtatzen du.
     */
    public enum Tamaina { txikia, ertaina, handia }

    // --- ATRIBUTUAK ---
    private String id;          // Identifikadore bakarra (adib. P001)
    private String cliente;      // Bezeroaren izena (hartzailea)
    private String destino;      // Bidalketaren helbidea (geokodifikaziorako erabilia)
    private String repartidor;   // Paketearen ardura duen langilearen izena
    private String estado;       // Egoera: "Biltegian", "Bidean" edo "Entregatuta"
    private Tamaina tamaina;     // Paketearen neurria (enum)

    /**
     * Eraikitzailea (Constructor): Pakete objektu berri bat sortzeko.
     */
    public Pakete(String id, String cliente, String destino, String repartidor, String estado, Tamaina tamaina) {
        this.id = id;
        this.cliente = cliente;
        this.destino = destino;
        this.repartidor = repartidor;
        this.estado = estado;
        this.tamaina = tamaina;
    }

    // --- GETTERRAK (Datuak irakurtzeko) ---
    
    public String getId()          { return id; }
    public String getCliente()     { return cliente; }
    public String getDestino()     { return destino; }
    public String getRepartidor()  { return repartidor; }
    public String getEstado()      { return estado; }
    public Tamaina getTamaina()    { return tamaina; }

    // --- SETTERRAK (Datuak aldatzeko) ---
    
    public void setId(String id)                   { this.id = id; }
    public void setCliente(String cliente)         { this.cliente = cliente; }
    public void setDestino(String destino)         { this.destino = destino; }
    public void setRepartidor(String repartidor)   { this.repartidor = repartidor; }
    public void setEstado(String estado)           { this.estado = estado; }
    public void setTamaina(Tamaina tamaina)        { this.tamaina = tamaina; }
}