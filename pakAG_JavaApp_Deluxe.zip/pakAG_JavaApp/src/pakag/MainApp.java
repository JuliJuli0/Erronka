package pakag;

import java.awt.Dimension;
import javax.swing.*;

/**
 * 🚀 APLIKAZIOAREN HASIERA (Main Class):
 * Programa honen helburua pakete kudeaketa sistema osoa abiaraztea da.
 * Exekuzio-fluxua bi urratsetan banatzen da: Segurtasuna (Login) eta Interfaze Nagusia.
 */
public class MainApp {
    
    /**
     * Metodo nagusia (Main): Java programa hemendik hasten da.
     * SwingUtilities.invokeLater erabiltzen da interfaze grafikoa modu seguruan kargatzeko
     * (Event Dispatch Thread - EDT).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            
            // ── 1. SEGURTASUN KONTROLA (Login) ──────────────────────────
            // Lehenik eta behin, saioa hasteko leihoa erakusten dugu.
            // Leiho hau "modala" da, beraz, programa hemen geldituko da itxi arte.
            LoginDialog login = new LoginDialog();
            login.setVisible(true);

            // Erabiltzaileak ez badu zuzen identifikatu (leihoa itxi badu, adibidez),
            // programa guztiz gelditzen dugu.
            if (!login.isLoginOk()) {
                System.exit(0); 
            }

            // ── 2. LEIHO NAGUSIA ERAIKI (Main Interface) ────────────────
            // Logina ondo joan bada, aplikazioaren panel nagusia prestatzen dugu.
            JFrame frame = new JFrame("pakAG Admin Panel — " + login.getNombreCompleto());
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            // Tamaina eta neurriak konfiguratu
            frame.setSize(1400, 850);
            frame.setMinimumSize(new Dimension(1200, 750));
            
            // Leihoa pantaila osora zabaldu hasieratik
            frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
            
            // Pantailaren erdian kokatu (monitorearen arabera)
            frame.setLocationRelativeTo(null);

            // ── 3. EDUKIA KARGATU ────────────────────────────────────────
            // MainPanel-ari login-etik lortutako izen osoa pasatzen diogu agurtzeko.
            // JScrollPane bat erabiltzen dugu edukia pantaila baino handiagoa bada mugitzeko.
            MainPanel content = new MainPanel(login.getNombreCompleto());
            JScrollPane scrollPane = new JScrollPane(content);
            scrollPane.setBorder(null); // Ertz itsusiak kendu
            
            frame.add(scrollPane);
            
            // Denaren amaieran, leihoa erabiltzaileari erakutsi
            frame.setVisible(true);
            
 
        });
    }
}