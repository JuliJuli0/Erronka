package pakag;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

/**
 * LOGIN DIALOG:
 * Aplikaziorako sarbidea kontrolatzen duen leiho modala.
 * Erabiltzaileak identifikatu eta 'kudeatzailea' rola dutela ziurtatzen du.
 */
public class LoginDialog extends JDialog {

    // --- KONEXIOAREN KONFIGURAZIOA ---
    private static final String DB_URL  = "jdbc:mysql://localhost:3306/entrega_kudeaketa";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "mysql";   

    private JTextField  tfUsuario;     // Erabiltzaile izena
    private JPasswordField tfPassword; // Pasahitz ezkutua
    private JLabel      lblError;      // Errore mezuak erakusteko etiketa

    // Loginaren emaitzak gordetzeko (Main-etik atzitzeko)
    private boolean loginOk = false;
    private String  nombreCompleto = "";
    private String  nanUsuario     = "";

    /**
     * Eraikitzailea: Login leihoaren oinarrizko ezaugarriak konfiguratzen ditu.
     */
    public LoginDialog() {
        super((Frame) null, "pakAG — Sarrera", true); // Modala da (fokua mantentzen du)
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        buildUI(); // Interfazea eraiki
        pack();    // Osagaien tamainara doitu
        setLocationRelativeTo(null); // Pantailaren erdian jarri
    }

    /**
     * buildUI(): Login leihoaren diseinu estetikoa eta egitura sortzen ditu.
     */
    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Colores.WHITE);

        // ── 1. GOIBURUKOA (Logoarekin) ──────────────────────────────────
        JPanel header = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 20));
        header.setBackground(Colores.SIDEBAR_BG);
        header.setPreferredSize(new Dimension(380, 90));

        // HTML erabili dugu testu baten barruan kolore desberdinak lortzeko
        JLabel logo = new JLabel("<html><span style='color:white;font-size:28px;font-weight:bold'>pak</span>"
            + "<span style='color:#4db8a4;font-size:28px;font-weight:bold'>AG</span></html>");
        JLabel sub  = new JLabel("Paketeak kudeatzeko sistema");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        sub.setForeground(new Color(0x9ab4c0));

        JPanel logoCol = new JPanel();
        logoCol.setLayout(new BoxLayout(logoCol, BoxLayout.Y_AXIS));
        logoCol.setOpaque(false);
        logoCol.add(logo);
        logoCol.add(sub);
        header.add(logoCol);

        // ── 2. FORMULARIOA (Erabiltzailea eta Pasahitza) ──────────────────
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Colores.WHITE);
        form.setBorder(new EmptyBorder(28, 36, 10, 36));
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6, 4, 6, 4);
        gc.anchor = GridBagConstraints.WEST;
        gc.fill   = GridBagConstraints.HORIZONTAL;

        Font labelFont = new Font("Segoe UI", Font.BOLD, 12);
        Font fieldFont = new Font("Segoe UI", Font.PLAIN, 13);

        // Erabiltzaile eremua
        gc.gridx=0; gc.gridy=0; gc.weightx=0;
        JLabel lUser = new JLabel("Erabiltzailea:");
        lUser.setFont(labelFont);
        lUser.setForeground(Colores.TEXT_DARK);
        form.add(lUser, gc);

        gc.gridx=0; gc.gridy=1; gc.weightx=1;
        tfUsuario = new JTextField(20);
        tfUsuario.setFont(fieldFont);
        tfUsuario.setBorder(new CompoundBorder(
            new LineBorder(Colores.BORDER_COLOR, 1, true),
            new EmptyBorder(7, 10, 7, 10)));
        form.add(tfUsuario, gc);

        // Pasahitz eremua
        gc.gridx=0; gc.gridy=2; gc.weightx=0;
        JLabel lPass = new JLabel("Pasahitza:");
        lPass.setFont(labelFont);
        lPass.setForeground(Colores.TEXT_DARK);
        form.add(lPass, gc);

        gc.gridx=0; gc.gridy=3; gc.weightx=1;
        tfPassword = new JPasswordField(20);
        tfPassword.setFont(fieldFont);
        tfPassword.setBorder(new CompoundBorder(
            new LineBorder(Colores.BORDER_COLOR, 1, true),
            new EmptyBorder(7, 10, 7, 10)));
        form.add(tfPassword, gc);

        // Erroreak erakusteko etiketa (hasieran hutsik)
        gc.gridx=0; gc.gridy=4;
        lblError = new JLabel(" ");
        lblError.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblError.setForeground(new Color(0xef4444));
        form.add(lblError, gc);

        // ── 3. BOTOIA (Sartu) ───────────────────────────────────────────────
        JPanel btnPanel = new JPanel(new BorderLayout());
        btnPanel.setBackground(Colores.WHITE);
        btnPanel.setBorder(new EmptyBorder(0, 36, 28, 36));

        // Botoi pertsonalizatua marrazteko (Anti-aliasing eta ertz biribilduak)
        JButton btnLogin = new JButton("Sartu  →") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isPressed() ? new Color(0x3aa090) : Colores.ACCENT);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                super.paintComponent(g);
            }
        };
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setPreferredSize(new Dimension(0, 40));
        btnLogin.setBorderPainted(false);
        btnLogin.setFocusPainted(false);
        btnLogin.setContentAreaFilled(false);
        btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnPanel.add(btnLogin, BorderLayout.CENTER);

        // ── 4. OINA (Footer - Argibideekin) ────────────────────────────────
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footer.setBackground(new Color(0xf8fafc));
        footer.setBorder(new MatteBorder(1, 0, 0, 0, Colores.BORDER_COLOR));
        JLabel footerLbl = new JLabel("Bakarrik kudeatzaileak sartu daitezke");
        footerLbl.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        footerLbl.setForeground(new Color(0x999999));
        footer.add(footerLbl);

        root.add(header,   BorderLayout.NORTH);
        root.add(form,     BorderLayout.CENTER);
        root.add(btnPanel, BorderLayout.SOUTH);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.add(root,   BorderLayout.CENTER);
        wrapper.add(footer, BorderLayout.SOUTH);
        setContentPane(wrapper);

        // ── EKINTZAK (ActionListeners) ────────────────────────────────────
        ActionListener doLogin = e -> intentarLogin();
        btnLogin.addActionListener(doLogin);
        tfPassword.addActionListener(doLogin); // Enter sakatzean login egin
        tfUsuario.addActionListener(e -> tfPassword.requestFocus()); // Enter-ekin pasahitzera salto
    }

    /**
     * intentarLogin(): Datu-basearekin balidazioa egiten duen metodo nagusia.
     */
    private void intentarLogin() {
        String usuario  = tfUsuario.getText().trim();
        String password = new String(tfPassword.getPassword());

        // Balidazio sinplea: eremuak ez daudela hutsik
        if (usuario.isEmpty() || password.isEmpty()) {
            setError("Bete itzazu eremu guztiak.");
            return;
        }

        try {
            // Driver-a kargatu eta konexioa ireki
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                
                // SQL kontsulta: Erabiltzailea eta pasahitza egiaztatu
                String sql = "SELECT nan, izena, abizena, rola FROM LANGILEA WHERE erabiltzailea=? AND pasahitza=?";
                
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, usuario);
                    ps.setString(2, password);
                    
                    try (ResultSet rs = ps.executeQuery()) {
                        // 1. Kasua: Ez da erabiltzailea aurkitu
                        if (!rs.next()) {
                            setError("Erabiltzailea edo pasahitza okerra.");
                            tfPassword.setText("");
                            return;
                        }

                        // 2. Kasua: Rola egiaztatu (soilik kudeatzaileak)
                        String rola = rs.getString("rola");
                        if (!"kudeatzailea".equals(rola)) {
                            setError("Sarbidea ukatua. Kudeatzaileak soilik.");
                            tfPassword.setText("");
                            return;
                        }

                        // ✅ LOGIN ONA: Datuak gorde eta leihoa itxi
                        nanUsuario     = rs.getString("nan");
                        nombreCompleto = rs.getString("izena") + " " + rs.getString("abizena");
                        loginOk = true;
                        dispose(); 
                    }
                }
            }
        } catch (Exception ex) {
            setError("Konexio errorea: Datu-basea martxan?");
        }
    }

    /**
     *  Errore mezuak gorriz erakutsi eta testu-eremuaren ertza aldatu.
     */
    private void setError(String msg) {
        lblError.setText(msg);
        tfUsuario.setBorder(new CompoundBorder(
            new LineBorder(new Color(0xef4444), 1, true),
            new EmptyBorder(7, 10, 7, 10)));
    }

    // ── GETTERS (Datuak kanpotik eskuratzeko) ───────────────────────────
    public boolean isLoginOk()        { return loginOk; }
    public String  getNombreCompleto(){ return nombreCompleto; }
    public String  getNanUsuario()    { return nanUsuario; }
}