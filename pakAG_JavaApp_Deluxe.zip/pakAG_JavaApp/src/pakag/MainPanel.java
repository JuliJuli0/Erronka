package pakag;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * PANEL NAGUSIA (Main Layout):
 * Aplikazioaren egitura nagusia kudeatzen du: Albo-barra (Sidebar), 
 * Goiko-barra (TopBar) eta Eduki-eremua (CardLayout bidez).
 */
public class MainPanel extends JPanel {

    // Orrialdeen identifikadore finkoak
    private static final String PAGE_PANEL    = "panel";
    private static final String PAGE_REPARTO  = "repartidores";
    private static final String PAGE_PAQUETES = "paquetes";
    private static final String PAGE_INFORMES = "Hstoriala";

    private CardLayout   cardLayout;    // Orrialdez aldatzeko mekanismoa
    private JPanel       contentArea;   // Orrialdeak kokatzen diren lekua
    private JLabel       topTitle;      // Goiko izenburu dinamikoa
    private DataStore    dataStore;     // Datuen kudeatzailea
    private String       nombreKudeatzailea;

    // Azpipanelak (Sekzio bakoitzeko klaseak)
    private KontrolPanela    kontrolpanela;
    private PaketenPanela     paketenpanela;
    private BanatzailenPanela banatzailenpanela;
    private HistorialaPanela    historialapanela;

    private Map<String, JPanel> navItems = new LinkedHashMap<>();
    private String currentPage = PAGE_PANEL;

    /**
     * Eraikitzailea: Interfazearen oinarria prestatu eta hasierako datuak kargatu.
     */
    public MainPanel(String nombreKudeatzailea) {
        this.nombreKudeatzailea = nombreKudeatzailea;
        this.dataStore = new DataStore();
        
        setLayout(new BorderLayout());
        setBackground(Colores.BG);
        
        // Hiru zati nagusiak gehitu
        add(buildSidebar(),     BorderLayout.WEST);
        add(buildTopBar(),      BorderLayout.NORTH);
        add(buildContentArea(), BorderLayout.CENTER);
    }

    /**
     * navigateTo(): Orrialdez aldatzeaz arduratzen da.
     * Aldatzen den bakoitzean, datuak berriro kargatzen ditu sinkronizazioa ziurtatzeko.
     * @param page Pantailaratuko den orrialdearen izena.
     */
    private void navigateTo(String page) {
        // 1. ALBO-BARRAREN EGOERA (Aldaketa bisuala)
        JPanel oldItem = navItems.get(currentPage);
        if (oldItem != null) {
            oldItem.setBackground(Colores.SIDEBAR_BG);
            for (Component c : oldItem.getComponents())
                if (c instanceof JLabel) ((JLabel)c).setForeground(new Color(0x9ab4c0));
        }
        
        currentPage = page;
        JPanel newItem = navItems.get(page);
        if (newItem != null) {
            newItem.setBackground(Colores.SIDEBAR_ACTIVE);
            for (Component c : newItem.getComponents())
                if (c instanceof JLabel) ((JLabel)c).setForeground(Color.WHITE);
            newItem.repaint();
        }

        // 2. ORRIALDEA ALDATU (CardLayout)
        cardLayout.show(contentArea, page);

        // 3. DATUAK EGUNERATU (Refresh automatikoa)
        // Datu-baseko aldaketak berehala ikusteko, DataStore berria sortzen dugu
        this.dataStore = new DataStore(); 

        // Orrialde bakoitzaren arabera, beharrezko azpipanela freskatu
        switch (page) {
            case PAGE_PANEL:
                topTitle.setText("Panel Orokorra");
                if (kontrolpanela != null) {
                    kontrolpanela.setDataStore(dataStore);
                    kontrolpanela.rebuild(); // Metrika guztiak berriz kalkulatu
                    if (kontrolpanela.getMapaPanel() != null) {
                        kontrolpanela.getMapaPanel().cargarPuntosDesdeLista(dataStore.getPaquetes());
                    }
                }
                break;

            case PAGE_REPARTO:
                topTitle.setText("Banatzaileak");
                if (banatzailenpanela != null) {
                	banatzailenpanela.setDataStore(dataStore);
                	banatzailenpanela.refreshTable();
                }
                break;

            case PAGE_PAQUETES:
                topTitle.setText("Paketeak");
                if (paketenpanela != null) {
                    paketenpanela.setDataStore(dataStore);
                    paketenpanela.refreshTable();
                }
                break;

            case PAGE_INFORMES:
                topTitle.setText("Historiala");
                if (historialapanela != null) {
                    historialapanela.setDataStore(dataStore);
                    historialapanela.cargarDatos();
                }
                break;
        }
    }

    /**
     * buildSidebar(): Ezkerreko menua eraikitzen du logo eta nabigazio aukerekin.
     */
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(Colores.SIDEBAR_BG);
        sidebar.setPreferredSize(new Dimension(185, 0));

        // LOGOA
        JLabel logo = new JLabel("<html><span style='color:white'>pak</span><span style='color:#4db8a4'>AG</span></html>");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        logo.setBorder(new CompoundBorder(
            new MatteBorder(0,0,1,0, new Color(0x2a3f50)),
            new EmptyBorder(16,16,16,16)));
        logo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 65));
        sidebar.add(logo);

        // NABIGAZIO ELEMENTUAK
        addNavItem(sidebar, "⊞", "Panel Orokorra", PAGE_PANEL);
        addNavItem(sidebar, "👥", "Langileak",   PAGE_REPARTO);
        addNavItem(sidebar, "📦", "Paketeak",       PAGE_PAQUETES);
        addNavItem(sidebar, "📄", "Historiala",     PAGE_INFORMES);
        
        sidebar.add(Box.createVerticalGlue()); // Espazioa bete amaierara arte

        // SAIOA ITXI (Logout botoia)
        JPanel logoutItem = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        logoutItem.setBackground(Colores.SIDEBAR_BG);
        logoutItem.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        logoutItem.setBorder(new CompoundBorder(
            new MatteBorder(1,0,0,0, new Color(0x2a3f50)),
            new EmptyBorder(2,0,2,0)));
        logoutItem.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        
        JLabel logoutIcon = new JLabel("🚪");
        logoutIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
        logoutIcon.setForeground(new Color(0x9ab4c0));
        
        JLabel logoutText = new JLabel("Irten");
        logoutText.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        logoutText.setForeground(new Color(0x9ab4c0));
        
        logoutItem.add(logoutIcon); logoutItem.add(logoutText);
        
        // Logout-aren logika: Segurtasun leihoa eta berrabiarazi login-a
        logoutItem.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                Object[] options = {"BAI", "EZ"};
                int r = JOptionPane.showOptionDialog(MainPanel.this, "Ziur zaude irten nahi duzula?", "Saioa Itxi",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[1]);
                if (r == JOptionPane.YES_OPTION) {
                    SwingUtilities.getWindowAncestor(MainPanel.this).dispose();
                    new MainApp().main(null); // Berriro hasi
                }
            }
            public void mouseEntered(MouseEvent e) { logoutItem.setBackground(new Color(0x243447)); logoutText.setForeground(new Color(0xef4444)); }
            public void mouseExited(MouseEvent e)  { logoutItem.setBackground(Colores.SIDEBAR_BG); logoutText.setForeground(new Color(0x9ab4c0)); }
        });
        sidebar.add(logoutItem);
        return sidebar;
    }

    /**
     * addNavItem(): Menuko botoi bakoitza sortu eta bere efektuak (hover) definitzen ditu.
     */
    private void addNavItem(JPanel sidebar, String icon, String label, String page) {
        JPanel item = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0)) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (currentPage.equals(page)) {
                    g.setColor(Colores.ACCENT); // Aukeratutako orrialdean marra berdea
                    g.fillRect(0, 0, 3, getHeight());
                }
            }
        };
        item.setBackground(currentPage.equals(page) ? Colores.SIDEBAR_ACTIVE : Colores.SIDEBAR_BG);
        item.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        item.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JLabel iconLbl = new JLabel(icon);
        iconLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
        iconLbl.setForeground(currentPage.equals(page) ? Color.WHITE : new Color(0x9ab4c0));

        JLabel textLbl = new JLabel(label);
        textLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        textLbl.setForeground(currentPage.equals(page) ? Color.WHITE : new Color(0x9ab4c0));

        item.add(iconLbl); item.add(textLbl);
        navItems.put(page, item);

        item.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e)  { navigateTo(page); }
            @Override public void mouseEntered(MouseEvent e)  {
                if (!currentPage.equals(page)) { item.setBackground(new Color(0x243447)); textLbl.setForeground(Color.WHITE); }
            }
            @Override public void mouseExited(MouseEvent e)   {
                if (!currentPage.equals(page)) { item.setBackground(Colores.SIDEBAR_BG); textLbl.setForeground(new Color(0x9ab4c0)); }
            }
        });
        sidebar.add(item);
    }

    /**
     * buildTopBar(): Goiko informazio barra (Izenburua + Kudeatzailearen izena).
     */
    private JPanel buildTopBar() {
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(Colores.WHITE);
        topBar.setBorder(new CompoundBorder(new MatteBorder(0,0,1,0, Colores.BORDER_COLOR), new EmptyBorder(10,20,10,20)));
        
        topTitle = new JLabel("Panel Orokorra");
        topTitle.setFont(new Font("Segoe UI", Font.BOLD, 17));
        topTitle.setForeground(Colores.TEXT_DARK);
        
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        right.setOpaque(false);
        JLabel user = new JLabel("Kudeatzailea: " + nombreKudeatzailea);
        user.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        user.setForeground(new Color(0x333333));
        
        right.add(user);
        topBar.add(topTitle, BorderLayout.WEST);
        topBar.add(right,    BorderLayout.EAST);
        return topBar;
    }

    /**
     * buildContentArea(): Panel guztiak CardLayout barruan inizializatzen ditu.
     */
    private JPanel buildContentArea() {
        cardLayout    = new CardLayout();
        contentArea   = new JPanel(cardLayout);
        contentArea.setBackground(Colores.BG);

        // Panelak sortu
        kontrolpanela      = new KontrolPanela(dataStore);
        banatzailenpanela  = new BanatzailenPanela(dataStore);
        paketenpanela      = new PaketenPanela(dataStore);
        historialapanela   = new HistorialaPanela(dataStore);

        // --- KONEXIOA: TAULA -> MAPA ---
        // Panel Orokorrean pakete bat aukeratzean, mapa mugitu puntu horretara
        JTable tablaAzken = kontrolpanela.getTableAzkenPaketeak();
        if (tablaAzken != null) {
            tablaAzken.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting()) {
                    int row = tablaAzken.getSelectedRow();
                    if (row != -1) {
                        String id = tablaAzken.getValueAt(row, 0).toString();
                        for (Pakete p : dataStore.getPaquetes()) {
                            if (p.getId().equals(id)) {
                                kontrolpanela.getMapaPanel().aukeratuPakete(p);
                                break; // Bukatu bilaketa bat aurkitzean
                            }
                        }
                    }
                }
            });
        }

        // Panel bakoitza CardLayout-era gehitu identifikadore batekin
        JScrollPane dashScroll = new JScrollPane(kontrolpanela);
        dashScroll.setBorder(null);
        dashScroll.getViewport().setBackground(Colores.BG);

        contentArea.add(dashScroll,         PAGE_PANEL);
        contentArea.add(banatzailenpanela,  PAGE_REPARTO);
        contentArea.add(paketenpanela,      PAGE_PAQUETES);
        contentArea.add(historialapanela,     PAGE_INFORMES);

        cardLayout.show(contentArea, PAGE_PANEL);
        return contentArea;
    }
}