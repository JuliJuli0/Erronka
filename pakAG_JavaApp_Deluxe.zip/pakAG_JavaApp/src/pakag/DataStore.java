package pakag;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *  DATU-BILTEGIA (Data Access Object):
 * MySQL datu-basearen eta Java programaren arteko zubia. 
 * JDBC bidez konexioa kudeatzen du eta CRUD (Sortu, Irakurri, Eguneratu, Ezabatu) 
 * eragiketak egiten ditu LANGILEA, PAKETEA eta BANAKETA taulen gainean.
 */
public class DataStore {

    // --- KONEXIO KONFIGURAZIOA ---
    private static final String DB_URL  = "jdbc:mysql://localhost:3306/entrega_kudeaketa";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "mysql";

    private Connection conn;
    private List<Pakete>     paquetes     = new ArrayList<>(); // Paketeak memorian
    private List<Banatzailea>  repartidores = new ArrayList<>(); // Banatzaileak memorian

    /**
     * Eraikitzailea: Driver-a kargatu eta konexioa ezartzen du.
     * Ondoren, datu-baseko informazioa kargatzen du listetan.
     */
    public DataStore() {
        try {
            // MySQL Driver-a kargatu
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Konexioa ireki
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            
            // Hasierako datuak kargatu
            cargarRepartidores();
            cargarPaquetes();
        } catch (ClassNotFoundException e) {
            mostrarError("Ez da MySQL driverra aurkitu.", "Driver Error");
        } catch (SQLException e) {
            mostrarError("Ezin izan da datu-basera konektatu.\nErrorea: " + e.getMessage(), "Konexio Errorea");
        }
    }

    // ── DATUAK KARGATU ──────────────────────────────────────

    /**
     * LANGILEA taulako datu guztiak irakurri eta 'repartidores' zerrendan gordetzen ditu.
     */
    private void cargarRepartidores() throws SQLException {
        repartidores.clear(); // Zerrenda garbitu bikoizketak ekiditeko
        String sql = "SELECT nan, izena, abizena, telefonoa, erabiltzailea, pasahitza, rola, helbidea FROM LANGILEA ORDER BY izena";
        
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Banatzailea r = new Banatzailea(
                    rs.getString("nan"),
                    rs.getString("izena"),
                    rs.getString("abizena"),
                    rs.getString("erabiltzailea"),
                    rs.getString("pasahitza"),
                    rs.getString("rola"),
                    rs.getString("helbidea") != null ? rs.getString("helbidea") : ""
                );
                r.setTelefonoa(rs.getString("telefonoa")); 
                repartidores.add(r);
            }
        }
    }

    /**
     * Paketeak kargatzen ditu, JOIN bidez banaketa eta langile datuak elkartuz.
     */
    private void cargarPaquetes() throws SQLException {
        paquetes.clear();
        String sql =
            "SELECT p.pakete_id, p.hartzailea, p.helbidea, " +
            "       CONCAT(l.izena,' ',l.abizena,' (',l.nan,')') AS repartidor, " +
            "       CASE b.egoera " +
            "         WHEN 'zain'      THEN 'Biltegian' " +
            "         WHEN 'banatzen'  THEN 'Bidean' " +
            "         WHEN 'entregatua' THEN 'Entregatuta' " +
            "         ELSE b.egoera END AS estado, " +
            "       p.tamaina " +
            "FROM PAKETEA p " +
            "LEFT JOIN BANAKETA b ON p.pakete_id = b.pakete_id " +
            "LEFT JOIN LANGILEA l ON b.nan_langilea = l.nan " +
            "ORDER BY b.data_esleipena DESC";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                // Tamaina Enum-era pasatu (segurtasun kontrolarekin)
                String tamStr = rs.getString("tamaina");
                Pakete.Tamaina tam;
                try { tam = Pakete.Tamaina.valueOf(tamStr); }
                catch (Exception e) { tam = Pakete.Tamaina.ertaina; }

                String rep = rs.getString("repartidor");
                if (rep == null) rep = "Esleitu gabe";

                paquetes.add(new Pakete(
                    rs.getString("pakete_id"),
                    rs.getString("hartzailea"),
                    rs.getString("helbidea"),
                    rep,
                    rs.getString("estado") != null ? rs.getString("estado") : "Biltegian",
                    tam
                ));
            }
        }
    }

    /**
     * Historiala lortzen du (Log-ak).
     * @return String[] zerrenda bat taulan erakusteko.
     */
    public List<String[]> getHistorial() {
        List<String[]> rows = new ArrayList<>();
        if (conn == null) return rows;
        
        String sql = "SELECT h.log_id, h.pakete_id, " +
                     "IFNULL(CONCAT(l.izena, ' ', l.abizena), '—') AS langilea, " +
                     "h.azalpena, h.data_ordua " +
                     "FROM HISTORIALA h " +
                     "LEFT JOIN LANGILEA l ON h.nan_langilea = l.nan " +
                     "ORDER BY h.data_ordua DESC";
                     
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                rows.add(new String[]{
                    String.valueOf(rs.getInt("log_id")),
                    rs.getString("pakete_id"),
                    rs.getString("langilea"),
                    rs.getString("azalpena"),
                    rs.getString("data_ordua")
                });
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return rows;
    }

    // ── LANGILEEN  ───────────────────────────────────────────────

    /**
     * Langile berri bat txertatu bai memorian bai datu-basean.
     */
    public void addRepartidor(Banatzailea r) {
        repartidores.add(r);
        if (conn == null) return;
        try {
            String sql = "INSERT INTO LANGILEA (nan, izena, abizena, telefonoa, erabiltzailea, pasahitza, rola, helbidea) VALUES (?,?,?,?,?,?,?,?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, r.getId());
                ps.setString(2, r.getIzena());
                ps.setString(3, r.getAbizena());
                ps.setString(4, r.getTelefonoa());
                ps.setString(5, r.getErabiltzailea());
                ps.setString(6, r.getPasahitza());
                ps.setString(7, r.getRola());
                ps.setString(8, r.getHelbidea());
                ps.executeUpdate();
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }

    /**
     * Lehendik dagoen langile baten datuak eguneratu NAN erabiliz.
     */
    public void updateRepartidor(Banatzailea r) {
        if (conn == null) return;
        try {
            String sql = "UPDATE LANGILEA SET izena=?, abizena=?, telefonoa=?, erabiltzailea=?, pasahitza=?, rola=?, helbidea=? WHERE nan=?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, r.getIzena());
                ps.setString(2, r.getAbizena());
                ps.setString(3, r.getTelefonoa());
                ps.setString(4, r.getErabiltzailea());
                ps.setString(5, r.getPasahitza());
                ps.setString(6, r.getRola());
                ps.setString(7, r.getHelbidea());
                ps.setString(8, r.getId());
                ps.executeUpdate();
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }

    /**
     * Langile bat ezabatzen du indizearen arabera.
     */
    public void removeRepartidor(int index) {
        Banatzailea r = repartidores.get(index);
        repartidores.remove(index);
        if (conn == null) return;
        try (PreparedStatement ps = conn.prepareStatement("DELETE FROM LANGILEA WHERE nan=?")) {
            ps.setString(1, r.getId()); 
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    // ──  PAKETE ────────────────────────────────────────────────

    /**
     * Pakete berria gehitu eta, langilea baldin badu, banaketa sortu.
     */
    public void addPaquete(Pakete p) {
        paquetes.add(p);
        if (conn == null) return;
        try {
            // 1. Gorde paketearen datu orokorrak
            String sqlP = "INSERT INTO PAKETEA (pakete_id, tamaina, helbidea, hartzailea) VALUES (?,?,?,?)";
            try (PreparedStatement ps = conn.prepareStatement(sqlP)) {
                ps.setString(1, p.getId());
                ps.setString(2, p.getTamaina().name());
                ps.setString(3, p.getDestino());
                ps.setString(4, p.getCliente());
                ps.executeUpdate();
            }
            
            // 2. Banaketa esleitu bada, BANAKETA taulan sartu
            String nan = extraerNan(p.getRepartidor());
            if (nan != null) {
                String sqlB = "INSERT INTO BANAKETA (data_esleipena, egoera, nan_langilea, pakete_id) VALUES (NOW(),?,?,?)";
                try (PreparedStatement ps = conn.prepareStatement(sqlB)) {
                    ps.setString(1, estadoToEgoera(p.getEstado()));
                    ps.setString(2, nan);
                    ps.setString(3, p.getId());
                    ps.executeUpdate();
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }

    /**
     * Pakete baten datuak eta bere banaketa egoera eguneratu.
     */
    public void updatePaquete(Pakete p) {
        if (conn == null) return;
        try {
            // 1. PAKETEA taula eguneratu
            String sqlP = "UPDATE PAKETEA SET hartzailea=?, helbidea=?, tamaina=? WHERE pakete_id=?";
            try (PreparedStatement ps = conn.prepareStatement(sqlP)) {
                ps.setString(1, p.getCliente());
                ps.setString(2, p.getDestino());
                ps.setString(3, p.getTamaina().name());
                ps.setString(4, p.getId());
                ps.executeUpdate();
            }

            // 2. BANAKETA taula kudeatu (Update edo Insert)
            String nan = extraerNan(p.getRepartidor());
            String sqlBUpdate = "UPDATE BANAKETA SET egoera=?, nan_langilea=? WHERE pakete_id=?";
            try (PreparedStatement ps = conn.prepareStatement(sqlBUpdate)) {
                ps.setString(1, estadoToEgoera(p.getEstado()));
                ps.setString(2, nan);
                ps.setString(3, p.getId());
                int rows = ps.executeUpdate();
                
                // Lehendik banaketarik ez bazuen, berria sortu
                if (rows == 0 && nan != null) {
                    String sqlBInsert = "INSERT INTO BANAKETA (data_esleipena, egoera, nan_langilea, pakete_id) VALUES (NOW(),?,?,?)";
                    try (PreparedStatement psIns = conn.prepareStatement(sqlBInsert)) {
                        psIns.setString(1, estadoToEgoera(p.getEstado()));
                        psIns.setString(2, nan);
                        psIns.setString(3, p.getId());
                        psIns.executeUpdate();
                    }
                }
            }
            refresh(); // Zerrendak berritu pantailan ikusteko
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarError("Errorea paketea eguneratzerakoan: " + e.getMessage(), "Eguneratze Errorea");
        }
    }
    
    /**
     * Paketea eta bere banaketa erregistroa ezabatu.
     */
    public void removePaquete(int index) {
        Pakete p = paquetes.get(index);
        paquetes.remove(index);
        if (conn == null) return;
        try {
            // Menpekotasunagatik, lehenengo banaketa ezabatu behar da
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM BANAKETA WHERE pakete_id=?")) {
                ps.setString(1, p.getId()); ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM PAKETEA WHERE pakete_id=?")) {
                ps.setString(1, p.getId()); ps.executeUpdate();
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }

    /**
     * Historial osoko log-ak ezabatu.
     */
    public void clearHistorial() {
        if (conn == null) return;
        try (PreparedStatement ps = conn.prepareStatement("DELETE FROM HISTORIALA")) {
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }
    
    // ──  LAGUNTZAILEAK ──────────────────────────────────────

    /**
     * Zerrenda guztiak datu-basetik berriro kargatzen ditu.
     */
    public void refresh() {
        if (conn == null) return;
        try { cargarRepartidores(); cargarPaquetes(); }
        catch (SQLException e) { e.printStackTrace(); }
    }

    /**
     * Hurrengo pakete ID-a kalkulatzen du (adibidez: PK005).
     */
    public String nextPaqueteId() {
        if (conn != null) {
            try (PreparedStatement ps = conn.prepareStatement("SELECT pakete_id FROM PAKETEA ORDER BY pakete_id DESC LIMIT 1");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String last = rs.getString(1).replaceAll("[^0-9]", "");
                    if (!last.isEmpty()) return String.format("PK%03d", Integer.parseInt(last) + 1);
                }
            } catch (SQLException e) { e.printStackTrace(); }
        }
        return "PK" + (paquetes.size() + 1);
    }

    /**
     * Interfazearen testua DB-ko balioetara bihurtzen du.
     */
    private String estadoToEgoera(String estado) {
        if (estado == null) return "zain";
        return switch (estado) {
            case "Bidean"      -> "banatzen";
            case "Entregatuta" -> "entregatua";
            default            -> "zain";
        };
    }

    /**
     * "Nombre (NAN)" formatutik soilik NAN-a ateratzen du.
     */
    private String extraerNan(String repStr) {
        if (repStr == null || repStr.equals("Esleitu gabe")) return null;
        for (Banatzailea r : repartidores) {
            if (repStr.contains(r.getId())) return r.getId();
        }
        return null;
    }

    public List<Pakete>    getPaquetes()    { return paquetes; }
    public List<Banatzailea> getRepartidores(){ return repartidores; }

    private void mostrarError(String msg, String titulo) {
        JOptionPane.showMessageDialog(null, msg, titulo, JOptionPane.ERROR_MESSAGE);
    }
}